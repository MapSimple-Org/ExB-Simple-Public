/** @jsx jsx */
import {
  React,
  ReactRedux,
  jsx,
  css,
  type DataSource,
  type FeatureDataRecord,
  type IMState,
  classNames
} from 'jimu-core'
// r024.41: Removed Button, Tooltip, Popper, Icon - replaced with plain HTML to avoid Calcite overhead
import FeatureInfo from './components/feature-info'
import { ListDirection } from '../config'
import { createQuerySimpleDebugLogger, substituteTokens, substituteLegacyTokens, convertTemplateToHtml, widgetConfigManager } from 'widgets/shared-code/mapsimple-common'
import { renderPopupContent } from './popup-render-utils'
import { buildFieldMetaMap } from './value-formatter'
import defaultMessages from './translations/default'
import { hooks } from 'jimu-core'
import Graphic from '@arcgis/core/Graphic'
import type MapView from '@arcgis/core/views/MapView'
import type SceneView from '@arcgis/core/views/SceneView'
import * as labelPointOperator from '@arcgis/core/geometry/operators/labelPointOperator.js'
/** JSAPI 5.0 exports GeometryUnion from geometry/types; 4.x does not. Cast-only usage. */
type GeometryUnion = any

const debugLogger = createQuerySimpleDebugLogger()

// r028.123/124: Hover feature highlight symbol per geometry type. Color is the configured
// hover-highlight color (Phase 2 — default #EA4335, matching the pin). Plain symbol JSON.
function buildHoverHighlightSymbol (geometryType: string, rgb: [number, number, number]): any {
  switch (geometryType) {
    case 'polyline':
      return { type: 'simple-line', color: [...rgb, 1], width: 4 }
    case 'polygon':
    case 'extent':
      return { type: 'simple-fill', color: [...rgb, 0.15], outline: { color: [...rgb, 1], width: 3 } }
    default: // point, multipoint
      return { type: 'simple-marker', style: 'circle', color: [...rgb, 0], size: 16, outline: { color: [...rgb, 1], width: 3 } }
  }
}

/**
 * r024.25: Factory function to create CIM teardrop pin symbol structure
 * Creates the symbol ONCE and returns the data structure for reuse.
 * This avoids creating new symbol objects on every hover and every animation frame.
 * 
 * @param baseColor - RGBA array for the main pin color
 * @param lighterColor - RGBA array for the center circle (lighter variant)
 * @returns CIM symbol JSON structure
 */
function createCIMPinSymbolData(
  baseColor: [number, number, number, number],
  lighterColor: [number, number, number, number]
) {
  return {
    type: 'CIMSymbolReference',
    symbol: {
      type: 'CIMPointSymbol',
      symbolLayers: [
        {
          type: 'CIMVectorMarker',
          enable: true,
          size: 28,
          anchorPointUnits: 'Relative',
          anchorPoint: { x: 0, y: -0.5 }, // Default resting position
          frame: { xmin: 0, ymin: 0, xmax: 24, ymax: 24 },
          markerGraphics: [
            {
              // Outer teardrop shape (Y-flipped for CIM)
              type: 'CIMMarkerGraphic',
              geometry: {
                rings: [[
                  [12, 22], [10.5, 22], [9, 21.5], [7.5, 20.5],
                  [6, 19], [5.5, 17.5], [5, 15],
                  [5, 13.5], [5.5, 11], [6.5, 8.5],
                  [8, 6], [10, 3.5], [12, 2],
                  [14, 3.5], [16, 6], [17.5, 8.5],
                  [18.5, 11], [19, 13.5],
                  [19, 15], [18.5, 17.5], [18, 19],
                  [16.5, 20.5], [15, 21.5], [13.5, 22], [12, 22]
                ]]
              },
              symbol: {
                type: 'CIMPolygonSymbol',
                symbolLayers: [
                  {
                    type: 'CIMSolidStroke',
                    enable: true,
                    width: 1.5,
                    color: [255, 255, 255, 255] // White outline
                  },
                  {
                    type: 'CIMSolidFill',
                    enable: true,
                    color: baseColor
                  }
                ]
              }
            },
            {
              // Inner circle "eye" (Y-flipped for CIM)
              type: 'CIMMarkerGraphic',
              geometry: {
                rings: [[
                  [12, 17.5], [13, 17.3], [13.8, 16.8],
                  [14.3, 16], [14.5, 15], [14.3, 14],
                  [13.8, 13.2], [13, 12.7], [12, 12.5],
                  [11, 12.7], [10.2, 13.2], [9.7, 14],
                  [9.5, 15], [9.7, 16], [10.2, 16.8],
                  [11, 17.3], [12, 17.5]
                ]]
              },
              symbol: {
                type: 'CIMPolygonSymbol',
                symbolLayers: [
                  {
                    type: 'CIMSolidStroke',
                    enable: true,
                    width: 1,
                    color: [255, 255, 255, 255] // White outline
                  },
                  {
                    type: 'CIMSolidFill',
                    enable: true,
                    color: lighterColor
                  }
                ]
              }
            }
          ],
          scaleSymbolsProportionally: true,
          respectFrame: true
        }
      ]
    }
  }
}

/**
 * Trash icon as CSS background-image (r021.44 memory optimization)
 * Instead of creating 600 React component instances of <TrashOutlined>,
 * we use a single CSS style with SVG data-uri that's reused across all items.
 * This eliminates 600 component instances + 600 DOM nodes.
 * SVG source: jimu-icons/svg/outlined/editor/trash.svg
 */
// r024.41: Plain HTML icons - SVG data URIs instead of jimu-ui Icon components
// This eliminates Calcite shadow DOM overhead for 600+ result items

const trashIconStyle = css`
  width: 18px;
  height: 18px;
  background-image: url('data:image/svg+xml;utf8,<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 6.5C6 6.22386 6.22386 6 6.5 6C6.77614 6 7 6.22386 7 6.5V12.5C7 12.7761 6.77614 13 6.5 13C6.22386 13 6 12.7761 6 12.5V6.5Z" fill="%236a6a6a"/><path d="M9.5 6C9.22386 6 9 6.22386 9 6.5V12.5C9 12.7761 9.22386 13 9.5 13C9.77614 13 10 12.7761 10 12.5V6.5C10 6.22386 9.77614 6 9.5 6Z" fill="%236a6a6a"/><path fill-rule="evenodd" clip-rule="evenodd" d="M11 0H5C4.44772 0 4 0.447715 4 1V3H0.5C0.223858 3 0 3.22386 0 3.5C0 3.77614 0.223858 4 0.5 4H2.1L2.90995 15.0995C2.96107 15.6107 3.39124 16 3.90499 16H12.095C12.6088 16 13.0389 15.6107 13.09 15.0995L13.9 4H15.5C15.7761 4 16 3.77614 16 3.5C16 3.22386 15.7761 3 15.5 3H12V1C12 0.447715 11.5523 0 11 0ZM11 3V1H5V3H11ZM12.895 4H3.10499L3.90499 15H12.095L12.895 4Z" fill="%236a6a6a"/></svg>');
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  display: inline-block;
`

const zoomToIconStyle = css`
  width: 18px;
  height: 18px;
  background-image: url('data:image/svg+xml;utf8,<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 10.5V12C0 12.5523 0.447716 13 1 13H2.5V12H1L1 10.5H0ZM2.5 1H1C0.447715 1 0 1.44772 0 2V3.5H1V2L2.5 2V1ZM0 8.5H1V5.5H0V8.5ZM4.5 1V2H7.5V1H4.5ZM9.5 1V2H11V3.5H12V2C12 1.44772 11.5523 1 11 1H9.5ZM6.31802 13.682C7.95595 15.3199 10.5424 15.4312 12.3092 14.0159L14.1569 15.864L14.864 15.1569L13.0166 13.3085C14.4312 11.5416 14.3197 8.9557 12.682 7.31802C10.9246 5.56066 8.07538 5.56066 6.31802 7.31802C4.56066 9.07538 4.56066 11.9246 6.31802 13.682ZM7.02513 12.9749C5.65829 11.608 5.65829 9.39196 7.02513 8.02513C8.39196 6.65829 10.608 6.65829 11.9749 8.02513C13.3417 9.39196 13.3417 11.608 11.9749 12.9749C10.608 14.3417 8.39196 14.3417 7.02513 12.9749ZM9 13V11H7V10H9V8H10V10H12V11H10V13H9Z" fill="%236a6a6a"/></svg>');
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  display: inline-block;
`

// r026.009: Pan/center icon — jimu HandOutlined (same SVG as Results Menu "Pan to")
const panToIconStyle = css`
  width: 18px;
  height: 18px;
  background-image: url('data:image/svg+xml;utf8,<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M3.169 5.309V3.048c0-.492.195-.963.543-1.311a1.853 1.853 0 011.311-.543c.489 0 .956.171 1.299.479.038-.048.079-.093.122-.137A1.853 1.853 0 017.731 1c.465 0 .934.177 1.287.536.103.104.194.222.27.351.333-.275.744-.411 1.151-.411.465 0 .934.177 1.287.536.164.167.297.367.393.596.308-.212.669-.317 1.027-.317.465 0 .934.177 1.287.536.353.358.562.868.567 1.488 0 .008.001.016.001.024V10.89c0 1.237-.399 2.277-1.143 3.008C13.115 14.627 12.078 15 10.89 15H6.719c-.646 0-1.262-.271-1.698-.747L1.606 10.528a2.237 2.237 0 01-.603-1.445 2.237 2.237 0 01.458-1.497l1.708-2.277zM7.156 2.238c-.15.153-.279.408-.279.809v1.805a.5.5 0 01-.748.434.497.497 0 01-.252-.434V2.943c0-.42-.328-.749-.854-.749a.854.854 0 00-.604.25.854.854 0 00-.25.604v2.399c.001.019.001.038 0 .058v2.677a.5.5 0 01-1 0V6.976l-.908 1.21a1.237 1.237 0 00-.26.848c.015.304.136.593.342.818l3.415 3.725c.246.269.595.423.961.423h4.17c.979 0 1.746-.304 2.267-.816.52-.51.843-1.275.843-2.294V4.358a.5.5 0 000-.021c0-.402-.129-.657-.28-.81a.648.648 0 00-.574-.238.648.648 0 00-.574.238c-.145.147-.274.394-.28.766v.56a.5.5 0 01-1 0v-.515a.5.5 0 01.001-.055V3.524c0-.402-.129-.657-.28-.81a.648.648 0 00-.574-.238c-.12 0-.236.025-.342.063a.648.648 0 00-.223.175 1.16 1.16 0 00-.184.283 1.39 1.39 0 00-.095.527v1.328a.5.5 0 01-1 0V3.047c0-.402-.129-.657-.28-.81A.648.648 0 007.731 2a.648.648 0 00-.575.238z" fill="%236a6a6a"/></svg>');
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  display: inline-block;
`

const moreIconStyle = css`
  width: 22px;
  height: 22px;
  background-image: url('data:image/svg+xml;utf8,<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="3" cy="8" r="1.5" fill="%236a6a6a"/><circle cx="8" cy="8" r="1.5" fill="%236a6a6a"/><circle cx="13" cy="8" r="1.5" fill="%236a6a6a"/></svg>');
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  display: inline-block;
`

// r024.41: Action button style - plain HTML button replacing jimu-ui Button
const actionButtonStyle = css`
  padding: 6px;
  min-width: 32px;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.15s ease;
  
  &:hover {
    background-color: rgba(0, 0, 0, 0.08);
  }
  
  &:focus {
    outline: 2px solid var(--sys-color-primary-main);
    outline-offset: 1px;
  }
  
  &:active {
    background-color: rgba(0, 0, 0, 0.12);
  }
`

// r024.46: Dropdown menu base style - direction set dynamically via inline style
const dropdownMenuBaseStyle = css`
  position: absolute;
  right: 0;
  min-width: 140px;
  padding: 4px 0;
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  z-index: 1000;
`

const menuItemStyle = css`
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 8px 12px;
  border: none;
  background: none;
  font-size: 0.875rem;
  cursor: pointer;
  text-align: left;
  color: inherit;
  
  &:hover {
    background: var(--ref-palette-neutral-200);
  }
`

export interface ResultItemProps {
  widgetId: string
  popupTemplate: any
  defaultPopupTemplate: any
  data: FeatureDataRecord
  dataSource: DataSource
  // r028.055: hoverPinColor removed from props, now read from widgetConfigManager singleton
  expandByDefault: boolean
  onClick: (record: FeatureDataRecord) => void
  onRemove: (record: FeatureDataRecord) => void
  /** r023.32: Zoom to single record. When provided, Zoom to appears in menu and (when expanded) as inline icon. */
  onZoomTo?: (record: FeatureDataRecord) => void
  /** r026.009: Pan to single record (center without zoom). */
  onPanTo?: (record: FeatureDataRecord) => void
  // r028.056: zoomOnResultClick and panOnResultClick removed from props, now read from widgetConfigManager singleton
  /** r026.002: When true, render using our own {{field}} substitution + markdown instead of Esri Feature widget */
  isCustomTemplate?: boolean
  /** r026.005: Raw template string for card rendering (stored in cache, not on popupTemplate) */
  rawTemplate?: string
  /** r028.111: When true, render the SelectAttributes field table through our shared
   *  renderer (renderPopupContent) instead of Esri FeatureInfo, so the card matches
   *  the on-map popup (aliases, formatted dates/numbers, coded domains, both brace
   *  styles in the title). PopupSetting/web-map popups stay on FeatureInfo. */
  isSelectAttributes?: boolean
  /** r028.117 (Phase 2.1): per-field alias overrides (fieldName -> label) for the
   *  reconstructed SelectAttributes queryConfig. Without this the card loses the
   *  admin label overrides the on-map popup gets from the real query config. */
  resultFieldAliases?: { [fieldName: string]: string }
  /** r028.033: Factory-format composite key for map-to-card identification (matches COMPOSITE_KEY on FeatureLayer graphics) */
  factoryCompositeKey?: string
  // r022.106: Hover preview props
  mapView?: MapView | SceneView
  // r022.106: Hover pins live on mapView.graphics (always renders on top of
  // all layers). r027.082 moved them to a per-widget GraphicsLayer, but that
  // caused z-order issues (results layers recreated on each query landed above
  // the hover layer). r027.091 moved them back. Cross-widget safety is handled
  // by scoped cleanup (remove individual graphic refs, never removeAll).
}

const style = css`
  overflow: visible;  /* r024.41: Changed from auto to allow dropdown menu to extend outside */
  flex-flow: row;
  cursor: pointer;
  flex-shrink: 0;
  min-height: 2rem;
  position: relative;
  transition: background-color 0.15s ease-in-out;
  /* r028.036: Breathing room when scrollIntoView({ block: 'start' }) pins this card to the top */
  &[data-composite-key] { scroll-margin-top: 4px; }
  
  /* r023.34: When expanded, stacked action icons + content need more height. The 4.5rem floor was
     sized for a 2-icon stack (2x32 + gap + offsets fits in 72px). */
  &.result-item-expanded {
    min-height: 4.5rem;
  }
  /* r028.142 (TODO #42): the default config stacks THREE icons (~104px), which escaped the
     overflow:visible card and bled onto the next card. Floor follows the count; 1-2 icons keep
     today's height (Adam's ruling: grow the card, actions stay one click away). */
  &.result-item-expanded[data-action-count='3'] {
    min-height: 6.75rem;
  }
  /* r028.145: the inner feature-info box carries its own border and floors at 4.5rem, so when the
     CARD grew to 6.75rem its bottom border ended mid-card as a stray short line (Adam's manual
     pass, 2026-08-14). Stretch the inner box with the card in the 3-icon case only - both content
     branches use .feature-info-expanded; specificity (0,3,0) outranks their own (0,2,0) floors.
     1-2 icon rows keep the untouched 4.5rem inner floor by design. */
  &.result-item-expanded[data-action-count='3'] .feature-info-expanded {
    min-height: 6.75rem;
  }
  
  /* Add right padding to prevent header text from running into action buttons */
  padding-right: 44px;  /* 32px button + buffer (vertical stack uses same width) */
  
  &.selected {
    outline: 2px solid var(--sys-color-primary-main);
  }
  
  /* r022.106: Hover preview - visual feedback in result row */
  &:hover {
    background-color: rgba(204, 0, 255, 0.08);  /* Neon purple tint */
  }

  /* r028.033: Map-to-card flash when popup opens for this feature on the map */
  &.map-identified-flash {
    animation: mapIdentifiedFlash 1.2s ease-in-out;
  }
  @keyframes mapIdentifiedFlash {
    0% { background-color: transparent; }
    15% { background-color: rgba(204, 0, 255, 0.14); }
    50% { background-color: rgba(204, 0, 255, 0.14); }
    100% { background-color: transparent; }
  }

  .result-actions-menu {
    position: absolute;
    top: 4px;
    right: 4px;
    z-index: 10;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    gap: 2px;
  }
  
  .result-actions-menu.result-actions-expanded {
    flex-direction: column;
    align-items: stretch;
    justify-content: flex-start;
  }
  
  .result-actions-toggle {
    opacity: 1;
    color: var(--sys-color-on-surface);
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    
    &:hover {
      color: var(--sys-color-primary-main);
    }
    
    min-width: 32px;
    min-height: 32px;
  }
  
  /* Ensure the FeatureInfo component respects the padding */
  .feature-info-component {
    width: 100%;
  }
  
  /* Make the header wrap if it's still too long */
  .esri-feature__title {
    word-wrap: break-word;
    overflow-wrap: break-word;
    padding-right: 8px;
  }
`

/**
 * QueryResultItem - displays a single query result record.
 *
 * r023.32-33: Result actions (Zoom to, Remove) adapt to expand state:
 * - When expanded: Inline icons stacked vertically (Zoom to, Remove) for quick access.
 * - When collapsed: Three-dot menu to save space; same actions in dropdown.
 * - Horizontal layout (no collapse): Always shows inline icons.
 *
 * zoomOnResultClick (r023.31) defaults to false; Zoom to is explicit via menu or inline icon.
 * No manual cleanup needed: state, Popper, and callbacks are React-managed.
 */
/**
 * Helper: Convert hex color to RGB array for CIM symbols
 * @param hex - Hex color string (e.g., '#EA4335' or 'EA4335')
 * @returns RGB array [r, g, b, alpha] for CIM symbol (e.g., [234, 67, 53, 230])
 */
function hexToRgb(hex: string, alpha: number = 230): [number, number, number, number] {
  // Remove # if present
  const cleanHex = hex.replace('#', '')
  
  // Parse RGB
  const r = parseInt(cleanHex.substring(0, 2), 16)
  const g = parseInt(cleanHex.substring(2, 4), 16)
  const b = parseInt(cleanHex.substring(4, 6), 16)
  
  return [r, g, b, alpha]
}

export const QueryResultItem = (props: ResultItemProps) => {
  const { widgetId, data, dataSource, popupTemplate, defaultPopupTemplate, onClick, onRemove, onZoomTo, onPanTo, isCustomTemplate, rawTemplate, isSelectAttributes, resultFieldAliases, expandByDefault = false, factoryCompositeKey, mapView } = props
  const getI18nMessage = hooks.useTranslation(defaultMessages)
  const [menuOpen, setMenuOpen] = React.useState(false)
  const [menuDropUp, setMenuDropUp] = React.useState(false)
  const menuButtonRef = React.useRef<HTMLButtonElement>(null)
  const [isExpanded, setIsExpanded] = React.useState(expandByDefault)

  // r023.33 / r024.19: Sync with expandByDefault when parent toggles Expand All / Collapse All
  // Only update if value actually changed to avoid unnecessary re-renders
  React.useEffect(() => {
    setIsExpanded(prev => {
      if (prev !== expandByDefault) {
        return expandByDefault
      }
      return prev  // No change, no re-render
    })
  }, [expandByDefault])
  
  // r027.000: ExB 1.20 — coerce getId() to string (now returns string | number)
  const recordId = String(data.getId())
  
  // r022.106: Hover preview - refs for hover graphic management
  const hoverGraphicRef = React.useRef<Graphic | null>(null)
  const hoverTimeoutRef = React.useRef<number | null>(null)
  const animationRef = React.useRef<number | null>(null) // r022.108: Spring animation ID
  // r028.123: Hover feature highlight graphic (in addition to the pin). One per item;
  // the item's geometry is constant, so it is created once and toggled visible.
  const hoverHighlightRef = React.useRef<Graphic | null>(null)
  
  // r028.052: Migrated from Redux selector to WidgetConfigManager singleton (Step 4)
  const resultListDirection = widgetConfigManager.getResultListDirection(widgetId)
  const isVerticalAlign = resultListDirection !== ListDirection.Horizontal
  // r028.055: Migrated from prop-drilling to WidgetConfigManager singleton (Step 9)
  const hoverPinColor = widgetConfigManager.getHoverPinColor(widgetId)
  // r028.124: Hover feature highlight color (Phase 2), read from the singleton.
  const hoverHighlightColor = widgetConfigManager.getHoverHighlightColor(widgetId)
  // r028.125: Hover on/off toggles (Phase 3), default on.
  const hoverPinEnabled = widgetConfigManager.getHoverPinEnabled(widgetId)
  const hoverHighlightEnabled = widgetConfigManager.getHoverHighlightFeature(widgetId)
  // r028.056: Migrated from prop-drilling to WidgetConfigManager singleton (Steps 7-8)
  const zoomOnResultClick = widgetConfigManager.getZoomOnResultClick(widgetId)
  const panOnResultClick = widgetConfigManager.getPanOnResultClick(widgetId)
  // r028.142 (TODO #42): stacked-toolbar button count - trash always renders, zoom/pan mirror the
  // gates on the buttons themselves (~line 1057/1069). Drives data-action-count so the card's
  // expanded min-height fits the stack instead of letting it bleed onto the next card.
  const stackedActionCount = 1 + (onZoomTo && !zoomOnResultClick ? 1 : 0) + (onPanTo && !panOnResultClick ? 1 : 0)
  debugLogger.log('SETTINGS', {
    event: 'singletonConfigRead',
    source: 'query-result-item',
    widgetId,
    resultListDirection,
    isVerticalAlign,
    hoverPinColor,
    zoomOnResultClick,
    panOnResultClick
  })

  // r024.25: Memoized CIM symbol data to avoid creating new objects on every hover/animation frame
  // The symbol data is created ONCE when color changes, not on every hover
  const memoizedSymbolData = React.useMemo(() => {
    const baseColor = hexToRgb(hoverPinColor || '#EA4335', 230)
    const lighterColor: [number, number, number, number] = [
      Math.min(255, Math.round(baseColor[0] * 1.2)),
      Math.min(255, Math.round(baseColor[1] * 1.2)),
      Math.min(255, Math.round(baseColor[2] * 1.2)),
      255
    ]
    return createCIMPinSymbolData(baseColor, lighterColor)
  }, [hoverPinColor])

  // r028.124: Memoized RGB for the hover feature highlight color (Phase 2).
  const hoverHighlightRgb = React.useMemo<[number, number, number]>(() => {
    const [r, g, b] = hexToRgb(hoverHighlightColor || '#EA4335', 255)
    return [r, g, b]
  }, [hoverHighlightColor])

  // r024.25: Ref to hold the live symbol data during animation (mutable)
  // This allows us to update anchorPoint without cloning the entire structure
  const symbolDataRef = React.useRef<ReturnType<typeof createCIMPinSymbolData> | null>(null)

  // Log when QueryResultItem renders
  React.useEffect(() => {
    debugLogger.log('EXPAND-COLLAPSE', {
      event: 'QueryResultItem-render',
      recordId,
      expandByDefault,
      timestamp: Date.now()
    })
  }, [recordId, expandByDefault])

  // Check if this record is currently selected
  const selected = ReactRedux.useSelector((state: IMState) =>
    // r027.000: ExB 1.20 — coerce getId() to string (now returns string | number)
    state.dataSourcesInfo?.[dataSource.id]?.selectedIds?.includes(String(data.getId()))
  )

  /**
   * Handle clicking on the result item.
   * Triggers zoom and popup opening (handled in toggleSelection callback).
   * r022.106: Also hides hover graphic on click
   * r022.108: Cancel spring animation on click
   */
  const handleClickResultItem = React.useCallback((e: React.MouseEvent) => {
    // Don't trigger zoom/popup if clicking the actions menu or menu button
    if ((e.target as HTMLElement).closest('.result-actions-menu') || (e.target as HTMLElement).closest('.result-actions-toggle')) {
      return
    }
    
    // r022.108: Cancel any running animation
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }
    
    // r022.106: Hide hover graphic on click (Option 1 behavior)
    if (hoverGraphicRef.current) {
      hoverGraphicRef.current.visible = false
      debugLogger.log('HOVER-PREVIEW', {
        event: 'hover-graphic-hidden-on-click',
        recordId,
        timestamp: Date.now()
      })
    }

    // r028.123: Hide the hover feature highlight on click (matches the pin)
    if (hoverHighlightRef.current) {
      hoverHighlightRef.current.visible = false
    }

    onClick(data)
  }, [onClick, data, recordId])

  // Handle clicking the remove menu item
  const handleRemove = React.useCallback((e: React.MouseEvent) => {
    e.stopPropagation()
    e.preventDefault()
    setMenuOpen(false)
    onRemove(data)
  }, [onRemove, data])

  // Handle clicking the zoom to menu item
  const handleZoomTo = React.useCallback((e: React.MouseEvent) => {
    e.stopPropagation()
    e.preventDefault()
    setMenuOpen(false)
    onZoomTo?.(data)
  }, [onZoomTo, data])

  // r026.009: Handle clicking the pan to menu item
  const handlePanTo = React.useCallback((e: React.MouseEvent) => {
    e.stopPropagation()
    e.preventDefault()
    setMenuOpen(false)
    onPanTo?.(data)
  }, [onPanTo, data])

  const onKeyUp = React.useCallback((evt) => {
    if (evt.key === 'Enter' || evt.key === ' ') {
      evt.preventDefault()
      evt.stopPropagation()
      handleClickResultItem(evt as any)
    }
  }, [handleClickResultItem])

  // r022.106: Hover preview - cleanup on unmount
  React.useEffect(() => {
    return () => {
      // r022.108: Cancel any running animation
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
        animationRef.current = null
      }
      
      // Clear any pending timeout
      if (hoverTimeoutRef.current) {
        window.clearTimeout(hoverTimeoutRef.current)
        hoverTimeoutRef.current = null
      }
      
      // r027.091: Remove hover graphic from mapView.graphics on unmount.
      // Scoped to this specific graphic ref (never removeAll).
      if (hoverGraphicRef.current && mapView?.graphics) {
        try {
          mapView.graphics.remove(hoverGraphicRef.current)
          debugLogger.log('HOVER-PREVIEW', {
            event: 'hover-graphic-removed-on-unmount',
            recordId,
            timestamp: Date.now()
          })
        } catch (error) {
          debugLogger.log('HOVER-PREVIEW', {
            event: 'hover-graphic-remove-error-on-unmount',
            recordId,
            error: error?.toString(),
            timestamp: Date.now()
          })
        }
        hoverGraphicRef.current = null
      }

      // r028.123: Remove the hover feature highlight from mapView.graphics on unmount.
      if (hoverHighlightRef.current && mapView?.graphics) {
        try {
          mapView.graphics.remove(hoverHighlightRef.current)
        } catch (error) {
          debugLogger.log('HOVER-PREVIEW', {
            event: 'hover-highlight-remove-error-on-unmount',
            recordId,
            error: error?.toString(),
            timestamp: Date.now()
          })
        }
        hoverHighlightRef.current = null
      }
    }
    // r027.091: mapView in deps so cleanup re-binds if view changes.
  }, [mapView, recordId])

  /**
   * r022.106: Handle mouse enter - show hover preview pin on map
   * r024.25: Optimized to use memoized CIMSymbol - no cloning on every animation frame
   * Debounced to 100ms to prevent flicker when moving across list items
   */
  const handleMouseEnter = React.useCallback(() => {
    // r027.091: Diagnostic for hover preview. mapView.graphics is the
    // map-level overlay (always renders on top of all layers).
    debugLogger.log('HOVER-PREVIEW', {
      event: 'handler-entered',
      recordId,
      hasMapView: !!mapView,
      mapViewGraphicsCount: mapView?.graphics?.length,
      timestamp: Date.now()
    })
    if (!mapView) {
      debugLogger.log('HOVER-PREVIEW', {
        event: 'handler-exit-no-mapview',
        recordId,
        timestamp: Date.now()
      })
      return
    }
    
    // Clear any existing timeout
    if (hoverTimeoutRef.current) {
      window.clearTimeout(hoverTimeoutRef.current)
    }
    
    // Debounce: Wait 100ms before showing graphic
    hoverTimeoutRef.current = window.setTimeout(() => {
      try {
        const geometry = data.getJSAPIGeometry()
        
        if (!geometry) {
          debugLogger.log('HOVER-PREVIEW', {
            event: 'hover-skipped-no-geometry',
            recordId,
            timestamp: Date.now()
          })
          return
        }

        // r028.125: highlight gated by its on/off toggle (Phase 3, default on).
        if (hoverHighlightEnabled) {
          // r028.123: Show the hover feature highlight — the record's full geometry drawn on
          // mapView.graphics. Added before the pin so the pin renders on top. Created once per
          // item (geometry is constant); r028.124 re-applies the symbol on reuse so a configured
          // color change takes effect on the next hover.
          if (!hoverHighlightRef.current) {
            hoverHighlightRef.current = new Graphic({
              geometry,
              symbol: buildHoverHighlightSymbol(geometry.type, hoverHighlightRgb) as any,
              attributes: { __hoverHighlight: true, __widgetId: widgetId }
            })
            mapView.graphics.add(hoverHighlightRef.current)
            debugLogger.log('HOVER-PREVIEW', {
              event: 'hover-highlight-created',
              recordId,
              geometryType: geometry.type,
              timestamp: Date.now()
            })
          } else {
            hoverHighlightRef.current.symbol = buildHoverHighlightSymbol(geometry.type, hoverHighlightRgb) as any
            hoverHighlightRef.current.visible = true
          }
        }

        // r028.125: pin gated by its on/off toggle (Phase 3, default on). When off, skip the
        // pin section below; the highlight (if enabled) was already handled above.
        if (!hoverPinEnabled) {
          return
        }

        // Calculate label point (same as popup logic)
        // r027.076: labelPointOperator.execute() typed `geometry: GeometryUnion`
        // in JSAPI 5.0; data.getJSAPIGeometry() returns the broader Geometry
        // base. The runtime value is always a GeometryUnion member (Point,
        // Polygon, Polyline, Multipoint, Extent, Mesh) so the cast is safe.
        const labelPoint = labelPointOperator.execute(geometry as GeometryUnion)
        
        if (!labelPoint) {
          debugLogger.log('HOVER-PREVIEW', {
            event: 'hover-skipped-no-labelpoint',
            recordId,
            geometryType: geometry.type,
            timestamp: Date.now()
          })
          return
        }
        
        // r024.25: Create a deep copy of the memoized symbol data for this graphic's animation.
        // This copy is made ONCE per hover start, not on every animation frame.
        // We use JSON parse/stringify for a clean deep copy since this is plain JSON data.
        symbolDataRef.current = JSON.parse(JSON.stringify(memoizedSymbolData))
        
        // Create or update hover graphic
        if (!hoverGraphicRef.current) {
          // r024.25: Set initial suspended position
          symbolDataRef.current.symbol.symbolLayers[0].anchorPoint = { x: 0, y: -1.2 }
          
          const cimSymbol = {
            type: 'cim',
            data: symbolDataRef.current
          }
          
          hoverGraphicRef.current = new Graphic({
            geometry: labelPoint,
            symbol: cimSymbol as any,
            // r028.045: Tag for bulk hide on pointerleave/scroll
            attributes: { __hoverPin: true, __widgetId: widgetId }
          })
          // r027.091: Add to mapView.graphics (map-level overlay, always
          // renders on top of all layers). Scoped cleanup on unmount removes
          // only this specific graphic ref — never removeAll().
          mapView.graphics.add(hoverGraphicRef.current)
          
          debugLogger.log('HOVER-PREVIEW', {
            event: 'hover-graphic-created',
            recordId,
            geometryType: geometry.type,
            symbolType: 'CIMSymbol-GooglePin-Animated-Optimized',
            color: hoverPinColor || '#EA4335',
            location: { x: labelPoint.x, y: labelPoint.y },
            timestamp: Date.now()
          })
          
          // r022.108 / r024.25: Start spring drop animation (optimized - no cloning)
          let start = null
          const targetY = -0.5  // Final resting position
          const initialY = -1.2 // Starting suspended height
          let currentY = initialY
          let velocity = 0
          
          const animate = (timestamp: number) => {
            if (!start) start = timestamp
            
            // Spring physics calculation
            const force = (targetY - currentY) * 0.15  // Stiffness
            velocity = (velocity + force) * 0.8         // Damping
            currentY += velocity
            
            // r024.25: Update anchor directly in the stored data ref (no cloning)
            if (hoverGraphicRef.current && mapView?.graphics && symbolDataRef.current) {
              try {
                // Mutate the stored data directly
                symbolDataRef.current.symbol.symbolLayers[0].anchorPoint = { x: 0, y: currentY }
                
                // Create a new symbol wrapper to trigger ESRI's change detection
                // The data object is reused, only the wrapper is new (minimal allocation)
                hoverGraphicRef.current.symbol = {
                  type: 'cim',
                  data: symbolDataRef.current
                } as any
              } catch (error) {
                debugLogger.log('HOVER-PREVIEW', {
                  event: 'animation-update-error',
                  recordId,
                  error: error?.toString(),
                  timestamp: Date.now()
                })
              }
            }
            
            // Continue until settled
            if (Math.abs(velocity) > 0.001 || Math.abs(targetY - currentY) > 0.001) {
              animationRef.current = requestAnimationFrame(animate)
            } else {
              debugLogger.log('HOVER-PREVIEW', {
                event: 'animation-complete',
                recordId,
                finalY: currentY,
                timestamp: Date.now()
              })
              animationRef.current = null
            }
          }
          
          animationRef.current = requestAnimationFrame(animate)
          
        } else {
          // Reuse existing graphic - update geometry and restart animation
          hoverGraphicRef.current.geometry = labelPoint
          hoverGraphicRef.current.visible = true
          
          // r022.108: Cancel any existing animation before starting new one
          if (animationRef.current) {
            cancelAnimationFrame(animationRef.current)
            animationRef.current = null
          }
          
          // r024.25: Reset anchor to suspended position for new animation
          if (symbolDataRef.current) {
            symbolDataRef.current.symbol.symbolLayers[0].anchorPoint = { x: 0, y: -1.2 }
          }
          
          debugLogger.log('HOVER-PREVIEW', {
            event: 'hover-graphic-reused',
            recordId,
            geometryType: geometry.type,
            location: { x: labelPoint.x, y: labelPoint.y },
            timestamp: Date.now()
          })
          
          // r022.108 / r024.25: Restart spring drop animation (optimized - no cloning)
          let start = null
          const targetY = -0.5
          const initialY = -1.2
          let currentY = initialY
          let velocity = 0
          
          const animate = (timestamp: number) => {
            if (!start) start = timestamp
            
            const force = (targetY - currentY) * 0.15
            velocity = (velocity + force) * 0.8
            currentY += velocity
            
            // r024.25: Update anchor directly (no cloning)
            if (hoverGraphicRef.current && mapView?.graphics && symbolDataRef.current) {
              try {
                symbolDataRef.current.symbol.symbolLayers[0].anchorPoint = { x: 0, y: currentY }
                hoverGraphicRef.current.symbol = {
                  type: 'cim',
                  data: symbolDataRef.current
                } as any
              } catch (error) {
                debugLogger.log('HOVER-PREVIEW', {
                  event: 'animation-update-error-reuse',
                  recordId,
                  error: error?.toString(),
                  timestamp: Date.now()
                })
              }
            }
            
            if (Math.abs(velocity) > 0.001 || Math.abs(targetY - currentY) > 0.001) {
              animationRef.current = requestAnimationFrame(animate)
            } else {
              debugLogger.log('HOVER-PREVIEW', {
                event: 'animation-complete-reuse',
                recordId,
                finalY: currentY,
                timestamp: Date.now()
              })
              animationRef.current = null
            }
          }
          
          animationRef.current = requestAnimationFrame(animate)
        }
      } catch (error) {
        debugLogger.log('HOVER-PREVIEW', {
          event: 'hover-graphic-error',
          recordId,
          error: error?.toString(),
          timestamp: Date.now()
        })
      }
    }, 100) // 100ms debounce
    // r027.091: mapView.graphics is always available when mapView is.
  }, [mapView, data, recordId, hoverPinColor, memoizedSymbolData, hoverHighlightRgb, hoverPinEnabled, hoverHighlightEnabled])

  /**
   * r022.106: Handle mouse leave - hide hover preview pin
   * r022.108: Cancel spring animation
   */
  const handleMouseLeave = React.useCallback(() => {
    // r022.108: Cancel any running animation
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }
    
    // Clear any pending timeout
    if (hoverTimeoutRef.current) {
      window.clearTimeout(hoverTimeoutRef.current)
      hoverTimeoutRef.current = null
    }
    
    // Hide hover graphic (don't destroy - reuse it)
    if (hoverGraphicRef.current) {
      hoverGraphicRef.current.visible = false

      debugLogger.log('HOVER-PREVIEW', {
        event: 'hover-graphic-hidden',
        recordId,
        timestamp: Date.now()
      })
    }

    // r028.123: Hide the hover feature highlight (reuse, don't destroy)
    if (hoverHighlightRef.current) {
      hoverHighlightRef.current.visible = false
    }
  }, [recordId])

  return (
    <div
      className={classNames('query-result-item', { selected, 'result-item-expanded': isExpanded || !isVerticalAlign })}
      data-action-count={stackedActionCount}
      data-composite-key={factoryCompositeKey}
      onClick={handleClickResultItem}
      onKeyUp={onKeyUp}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      css={style}
      role='option'
      aria-selected={selected}
      tabIndex={0}
    >
      {/* r026.002: CustomTemplate mode — our own {{field}} substitution + markdown rendering.
          r028.111: SelectAttributes mode also renders here (via renderPopupContent), so the
          card matches the on-map popup. Both bypass the Esri Feature widget but reuse its
          DOM structure/styling. PopupSetting (web-map popups) still falls through to FeatureInfo. */}
      {(isCustomTemplate && rawTemplate) || isSelectAttributes ? (
        <div
          className={classNames('feature-info-component d-flex align-items-center', { 'feature-info-expanded': isExpanded })}
          style={{ padding: '3px 4px' }}
          css={css`
            border: 1px solid var(--sys-color-divider-secondary);
            &.feature-info-expanded { min-height: 4.5rem; }
            .esri-widget__heading {
              font-size: 0.875rem !important;
              font-weight: 500 !important;
              margin: 0;
              color: var(--sys-color-surface-paper-text);
            }
            .esri-feature__text {
              font-size: 0.875rem;
              color: var(--sys-color-surface-paper-text);
              p { margin: 0; }
              p:last-child { margin-bottom: 0; }
              h3 { font-size: 1rem; font-weight: 600; font-style: normal; margin: 0 0 4px 0; }
              h4 { font-size: 0.9rem; font-weight: 600; font-style: normal; margin: 0 0 4px 0; }
              h5 { font-size: 0.85rem; font-weight: 600; font-style: normal; margin: 0 0 3px 0; }
              h6 { font-size: 0.8rem; font-weight: 600; font-style: normal; margin: 0 0 3px 0; }
              ul { margin: 2px 0 6px 0; padding-left: 20px; }
              li { margin: 1px 0; }
              hr { border: none; border-top: 1px solid var(--ref-palette-neutral-500); margin: 6px 0; }
              strong { font-weight: 700; }
              em { font-style: italic; }
              a { color: var(--sys-color-primary-main); text-decoration: none; }
              a:hover { text-decoration: underline; }
              img { max-width: 100%; height: auto; }
            }
          `}
        >
          {isVerticalAlign && (
            <button
              className='jimu-outline-inside flex-shrink-0'
              onClick={(e) => { e.stopPropagation(); setIsExpanded(!isExpanded) }}
              aria-label={isExpanded ? 'collapse' : 'expand'}
              css={css`
                background: none;
                border: none;
                cursor: pointer;
                min-width: 32px;
                min-height: 32px;
                padding: 6px;
                display: flex;
                align-items: center;
                justify-content: center;
                align-self: flex-start;
                border-radius: 2px;
                color: inherit;
                &:hover {
                  background-color: var(--sys-color-action-hover, rgba(0, 0, 0, 0.04));
                }
              `}
            >
              <div css={isExpanded
                ? css`width: 16px; height: 16px; background-image: url('data:image/svg+xml;utf8,<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14 4L8 12L2 4L14 4Z" fill="currentColor"/></svg>'); background-size: contain; background-repeat: no-repeat; background-position: center; display: inline-block;`
                : css`width: 16px; height: 16px; background-image: url('data:image/svg+xml;utf8,<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 2L12 8L4 14V2Z" fill="currentColor"/></svg>'); background-size: contain; background-repeat: no-repeat; background-position: center; display: inline-block;`
              } aria-hidden='true' />
            </button>
          )}
          <div className='flex-grow-1' dangerouslySetInnerHTML={{ __html: (() => {
            const attributes = data.feature?.attributes || {}
            let title: string
            let html: string

            if (isSelectAttributes) {
              // r028.111: Render the field table through the SAME shared function and the
              // SAME branch the on-map popup uses (SelectAttributes → renderFieldTableHtml),
              // so card == popup: alias labels, formatted dates/numbers, decoded domains.
              // The display field list is reconstructed from the popupTemplate's fieldInfos
              // (getPopupTemplate built those from the query item's resultDisplayFields).
              // fieldMeta (alias/type/domain) comes from the record's source layer schema.
              const fieldMeta = buildFieldMetaMap((data.feature as any)?.layer?.fields)
              const displayFields = ((popupTemplate?.fieldInfos as any[]) || [])
                .map(fi => fi?.fieldName)
                .filter(Boolean)
              const queryConfig = {
                resultFieldsType: 'SelectAttributes',
                resultDisplayFields: displayFields,
                resultTitleExpression: popupTemplate?.title || '',
                resultFieldAliases // r028.117 (Phase 2.1): admin label overrides
              }
              const result = renderPopupContent(attributes, queryConfig, undefined, fieldMeta)
              title = result.title
              html = result.contentHtml
            } else {
              // CustomTemplate mode (r026.002): {{field}} substitution + markdown.
              let substituted = substituteTokens(rawTemplate, attributes)
              substituted = substituteLegacyTokens(substituted, attributes)
              html = convertTemplateToHtml(substituted)
              const titleTemplate = popupTemplate.title || ''
              title = substituteTokens(titleTemplate, attributes)
              title = substituteLegacyTokens(title, attributes)
            }

            // Match Esri Feature widget DOM: title heading + text content
            const titleHtml = title ? `<div class="esri-widget__heading">${title}</div>` : ''
            const contentHtml = isExpanded || !isVerticalAlign ? `<div class="esri-feature__text">${html}</div>` : ''
            return `${titleHtml}${contentHtml}`
          })() }} />
        </div>
      ) : (
        <FeatureInfo
          graphic={data.feature as Graphic}
          popupTemplate={popupTemplate}
          defaultPopupTemplate={defaultPopupTemplate}
          togglable={isVerticalAlign}
          expandByDefault={expandByDefault}
          onExpandChange={isVerticalAlign ? setIsExpanded : undefined}
          dataSource={dataSource}
        />
      )}
      {/* r024.41: Plain HTML action buttons - NO jimu-ui, NO Calcite, NO click-outside listener */}
      {/* r024.46: When zoomOnResultClick is on, skip zoom button entirely.
          If collapsed and no zoom button, show trash directly (no three-dot menu needed). */}
      {/* r028.147: while this card's dropdown is open, lift its toolbar container above the
          siblings. The container's z-index:10 creates a stacking context, so the popup's own
          z-index:1000 is flattened to 10 outside it - and sibling toolbars (also 10, later in
          DOM) painted over the open menu. Pre-existing (r024.46-era), surfaced in the DCE
          walkthrough. */}
      <div className={classNames('result-actions-menu', { 'result-actions-expanded': (isExpanded || !isVerticalAlign) })} style={menuOpen ? { zIndex: 20 } : undefined}>
        {(isExpanded || !isVerticalAlign) ? (
          // r027.076: Explicit React.Fragment instead of <>…</> — the file uses
          // /** @jsx jsx */ (emotion) without a paired @jsxFrag pragma, so the
          // shorthand triggers TS17017. Spelling it out avoids touching the
          // file pragma.
          <React.Fragment>
            {onZoomTo && !zoomOnResultClick && (
              <button
                type="button"
                className="result-actions-toggle"
                css={actionButtonStyle}
                onClick={handleZoomTo}
                aria-label={getI18nMessage('zoomToRecord')}
                title={getI18nMessage('zoomToRecord')}
              >
                <span css={zoomToIconStyle} aria-hidden="true" />
              </button>
            )}
            {onPanTo && !panOnResultClick && (
              <button
                type="button"
                className="result-actions-toggle"
                css={actionButtonStyle}
                onClick={handlePanTo}
                aria-label={getI18nMessage('panToRecord')}
                title={getI18nMessage('panToRecord')}
              >
                <span css={panToIconStyle} aria-hidden="true" />
              </button>
            )}
            <button
              type="button"
              className="result-actions-toggle"
              css={actionButtonStyle}
              onClick={handleRemove}
              aria-label={getI18nMessage('removeResult')}
              title={getI18nMessage('removeResult')}
            >
              <span css={trashIconStyle} aria-hidden="true" />
            </button>
          </React.Fragment>
        ) : ((zoomOnResultClick || !onZoomTo) && (panOnResultClick || !onPanTo)) ? (
          /* r024.46/r026.009: Both zoom and pan are either default-click or absent — just show trash directly */
          <button
            type="button"
            className="result-actions-toggle"
            css={actionButtonStyle}
            onClick={handleRemove}
            aria-label={getI18nMessage('removeResult')}
            title={getI18nMessage('removeResult')}
          >
            <span css={trashIconStyle} aria-hidden="true" />
          </button>
        ) : (
          <div 
            css={css`position: relative;`}
            onBlur={(e) => {
              // Close menu when focus leaves the container (click elsewhere)
              if (!e.currentTarget.contains(e.relatedTarget as Node)) {
                setMenuOpen(false)
              }
            }}
          >
            <button
              ref={menuButtonRef}
              type="button"
              className="result-actions-toggle"
              css={actionButtonStyle}
              onClick={(e) => {
                e.stopPropagation()
                e.preventDefault()
                if (!menuOpen && menuButtonRef.current) {
                  // r024.46: Check if there's room below. Menu is ~80px tall.
                  const scrollParent = menuButtonRef.current.closest('.query-result-container')
                  if (scrollParent) {
                    const scrollRect = scrollParent.getBoundingClientRect()
                    const btnRect = menuButtonRef.current.getBoundingClientRect()
                    const spaceBelow = scrollRect.bottom - btnRect.bottom
                    setMenuDropUp(spaceBelow < 90)
                  }
                }
                setMenuOpen(!menuOpen)
              }}
              aria-label={getI18nMessage('resultActions')}
              title={getI18nMessage('resultActions')}
              aria-haspopup="menu"
              aria-expanded={menuOpen}
            >
              <span css={moreIconStyle} aria-hidden="true" />
            </button>
            {menuOpen && (
              <div css={dropdownMenuBaseStyle} style={menuDropUp ? { bottom: '36px' } : { top: '36px' }} role="menu" tabIndex={-1}>
                {onZoomTo && !zoomOnResultClick && (
                  <button
                    type="button"
                    role="menuitem"
                    onClick={handleZoomTo}
                    css={menuItemStyle}
                  >
                    <span css={css`${zoomToIconStyle}; width: 16px; height: 16px;`} aria-hidden="true" />
                    {getI18nMessage('zoomToRecord')}
                  </button>
                )}
                {onPanTo && !panOnResultClick && (
                  <button
                    type="button"
                    role="menuitem"
                    onClick={handlePanTo}
                    css={menuItemStyle}
                  >
                    <span css={css`${panToIconStyle}; width: 16px; height: 16px;`} aria-hidden="true" />
                    {getI18nMessage('panToRecord')}
                  </button>
                )}
                <button
                  type="button"
                  role="menuitem"
                  onClick={handleRemove}
                  css={menuItemStyle}
                >
                  <span css={css`${trashIconStyle}; width: 16px; height: 16px;`} aria-hidden="true" />
                  {getI18nMessage('removeResult')}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
