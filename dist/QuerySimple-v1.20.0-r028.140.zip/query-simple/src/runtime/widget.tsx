/** @jsx jsx */
import { React, jsx, css, type AllWidgetProps, DataSourceManager, type FeatureLayerDataSource, type FeatureDataRecord, MessageManager, DataRecordsSelectionChangeMessage, type DataSource } from 'jimu-core'
import { Paper, WidgetPlaceholder } from 'jimu-ui'
import { type IMConfig, QueryArrangeType, SelectionType } from '../config'
import defaultMessages from './translations/default'
import { getWidgetRuntimeDataMap } from './widget-config'
import { JimuMapViewComponent, type JimuMapView } from 'jimu-arcgis'

import { versionManager } from '../version-manager'
import { QueryTaskList } from './query-task-list'
import { TaskListInline } from './query-task-list-inline'
import { TaskListPopperWrapper } from './query-task-list-popper-wrapper'
import { QueryWidgetContext } from './widget-context'
import { createQuerySimpleDebugLogger, widgetConfigManager } from 'widgets/shared-code/mapsimple-common'
import { calculateRecordsExtent } from './zoom-utils'
import { WIDGET_VERSION } from '../version'
import { removeHashParam } from './hash-utils'
// Managers (extracted from class component, r018–r019)
import { UrlConsumptionManager } from './managers/url-consumption-manager'
import { WidgetVisibilityManager } from './managers/widget-visibility-manager'
import { MapViewManager } from './managers/map-view-manager'
import { GraphicsLayerManager } from './managers/graphics-layer-manager'
import { AccumulatedRecordsManager } from './managers/accumulated-records-manager'
import { EventManager, OPEN_WIDGET_EVENT, QUERYSIMPLE_SELECTION_EVENT, RESTORE_ON_IDENTIFY_CLOSE_EVENT } from './managers/event-manager'
import { SelectionRestorationManager } from './managers/selection-restoration-manager'
import { createResultGroupLayer, destroyResultLayers, buildCompositeKey, updateFeatureLayerRenderer } from './result-feature-layer-factory'
import { addResultFeatures, removeResultFeatures, clearResultFeatures, getExistingCompositeKeys, resetObjectIdCounter, resetKeyTracking } from './result-feature-layer-sync'
import { createAsyncSerializer } from '../utils/async-serializer'
import { setQueryConfigs, clearQueryConfigs, clearRecordRegistry } from './result-feature-layer-popup'
import type Extent from '@arcgis/core/geometry/Extent'
import type GroupLayer from '@arcgis/core/layers/GroupLayer'
import type GraphicsLayer from '@arcgis/core/layers/GraphicsLayer'
import type MapView from '@arcgis/core/views/MapView'
import type SceneView from '@arcgis/core/views/SceneView'

const debugLogger = createQuerySimpleDebugLogger()
const { iconMap } = getWidgetRuntimeDataMap()

// Event constants moved to EventManager (r018.59 - Chunk 7.1)

/**
 * QuerySimple Widget
 * 
 * A high-performance query widget for ArcGIS Experience Builder that provides:
 * - Universal SQL optimization for database index usage
 * - Dual-mode deep linking (hash fragments and query strings)
 * - Results accumulation across multiple queries
 * - Selection persistence and restoration
 * - Graphics layer highlighting for map visualization
 * 
 * Architecture:
 * This widget follows a "Hook & Shell" pattern where complex logic is extracted into
 * manager classes (UrlConsumptionManager, WidgetVisibilityManager, MapViewManager)
 * to keep the main widget class clean and maintainable.
 * 
 * @since 1.19.0-r018.18
 * @see {@link UrlConsumptionManager} for URL parameter handling
 * @see {@link WidgetVisibilityManager} for panel visibility detection
 * @see {@link MapViewManager} for map view reference management
 */
export default class Widget extends React.PureComponent<AllWidgetProps<IMConfig>, {
  initialQueryValue?: { shortId: string, value: string },
  isPanelVisible?: boolean,
  hasSelection?: boolean,
  selectionRecordCount?: number,
  resultsMode?: SelectionType,
  accumulatedRecords?: FeatureDataRecord[],
  resultsExtent?: Extent | null,
  graphicsLayerInitialized?: boolean,
  // r027.091: hoverLayerInitialized removed — hover pins use mapView.graphics
  activeTab?: 'query' | 'results',
  // r027.079: mirrors the field initializer at line 117/119. The class State
  // generic at this PureComponent declaration is what setState type-checks
  // against; without these two, setState({shouldUseInitialQueryValueForSelection})
  // and setState({jimuMapView}) tripped TS2353. Keep both shapes in sync.
  shouldUseInitialQueryValueForSelection?: boolean,
  jimuMapView?: JimuMapView | null
}> {
  static versionManager = versionManager
  // Chunk 1: URL Parameter Consumption Manager (r018.8)
  private urlConsumptionManager = new UrlConsumptionManager()
  // Chunk 2: Widget Visibility Engine Manager (r018.13) - Step 2.3: Switch to manager
  private visibilityManager = new WidgetVisibilityManager()
  
  // Refs must be declared before managers that use them
  private widgetRef = React.createRef<HTMLDivElement>()
  private graphicsLayerRef = React.createRef<GraphicsLayer | null>()
  // r028.004: Path 3 result GroupLayer (parallel to graphicsLayerRef for Path 2)
  private resultGroupLayerRef = React.createRef<GroupLayer | null>()
  // r028.087: Serialize syncResultFeatureLayers calls so concurrent invocations
  // (e.g. rapid query clicks) don't interleave diff/apply against the shared
  // _keysByWidget Set and produce duplicate features on the map.
  private syncResultFeatureLayersSerializer = createAsyncSerializer()
  // r027.091: hoverLayerRef removed — hover pins now use mapView.graphics
  // (always-on-top overlay). Per-graphic scoped cleanup prevents cross-widget
  // collateral damage. See docs/bugs/HOVER-PIN-CROSS-WIDGET-BUG.md.
  private mapViewRef = React.createRef<MapView | SceneView | null>()
  
  // Chunk 6: Map View Management Manager (r018.16) - Step 6.3: Switch to manager
  private mapViewManager = new MapViewManager(this.mapViewRef)
  // Chunk 4: Graphics Layer Management Manager (r018.24) - Step 4.2: Parallel execution
  private graphicsLayerManager = new GraphicsLayerManager(this.graphicsLayerRef, this.mapViewRef)
  // Chunk 5: Accumulated Records Management Manager (r018.26) - Step 5.1: Add manager without integration
  private accumulatedRecordsManager = new AccumulatedRecordsManager()
  // Chunk 7: Event Handling Manager (r018.59) - Step 7.1: Create Event Manager
  private eventManager = new EventManager()

  // Chunk 3: Selection & Restoration Manager (r019.1) - Section 3.1: Selection State Tracking
  private selectionRestorationManager = new SelectionRestorationManager(
    () => this.state, // stateGetter
    {
      onStateUpdate: (newState) => this.setState(newState as any)
    }
  )

  // r024.5: Register config in constructor so it's available before any callbacks fire
  // (handleMapViewChange can fire before componentDidMount)
  constructor(props: AllWidgetProps<IMConfig>) {
    super(props)
    widgetConfigManager.registerConfig(props.id, props.config)
  }

  state: {
    initialQueryValue?: { shortId: string, value: string },
    isPanelVisible?: boolean,
    hasSelection?: boolean,
    selectionRecordCount?: number,
    resultsMode?: SelectionType,
    accumulatedRecords?: FeatureDataRecord[],
    resultsExtent?: Extent | null,
    graphicsLayerInitialized?: boolean,
    activeTab?: 'query' | 'results',
    // Track when HelperSimple explicitly opens widget - only then should query-task-list use initialQueryValue for selection
    // Using state instead of ref ensures React triggers re-renders when flag changes
    shouldUseInitialQueryValueForSelection?: boolean
    // r025.041: JimuMapView for spatial draw tools (JimuDraw requires JimuMapView, not raw MapView)
    jimuMapView?: JimuMapView | null
  } = {
    resultsMode: SelectionType.NewSelection, // Default mode
    activeTab: 'query',
    resultsExtent: null,
    jimuMapView: null
  }

  /**
   * Handles tab change between "Query" and "Results" tabs.
   * 
   * @param activeTab - The tab to switch to ('query' or 'results')
   * 
   * @since 1.19.0-r017.0
   */
  handleTabChange = (activeTab: 'query' | 'results') => {
    this.setState({ activeTab })
  }

  /**
   * Resets the manual modifications flag when user starts fresh operations.
   * This allows hash-triggered queries to work again after explicit user actions.
   */
  resetManualModifications = () => {
    // FIX (r018.96): Removed manuallyRemovedRecordIds tracking - no longer needed
    // Duplicate detection in mergeResultsIntoAccumulated handles preventing duplicates
  }

  /**
   * Handles HelperSimple's open widget event.
   * QuerySimple should only process hash parameters when HelperSimple explicitly opens the widget.
   * This ensures HelperSimple remains the orchestrator and prevents autonomous hash processing.
   */
  handleOpenWidgetEvent = (event: CustomEvent) => {
    const { id } = this.props

    debugLogger.log('HASH-EXEC', {
      event: 'querysimple-handleopenwidgetevent-received',
      widgetId: id,
      eventWidgetId: event.detail?.widgetId,
      matches: event.detail?.widgetId === id,
      currentState: {
        shouldUseInitialQueryValueForSelection: this.state.shouldUseInitialQueryValueForSelection,
        hasInitialQueryValue: !!this.state.initialQueryValue,
        initialQueryValueShortId: this.state.initialQueryValue?.shortId,
        initialQueryValueValue: this.state.initialQueryValue?.value,
        currentUrlHash: window.location.hash.substring(1),
      },
      timestamp: Date.now()
    })

    // With surgical hash modification, the hash already contains only desired record IDs
    // No need to block processing - the hash is now a precise representation of selection intent

    // Only process if this event is for our widget
    if (event.detail?.widgetId !== id) {
      debugLogger.log('HASH-EXEC', {
        event: 'querysimple-handleopenwidgetevent-ignored-wrong-widget',
        widgetId: id,
        eventWidgetId: event.detail?.widgetId,
        timestamp: Date.now()
      })
      return
    }
    
    // NOTE: We don't check processed hashes here anymore
    // The check happens in onInitialValueFound after we know which shortId:value pair is being processed
    
    debugLogger.log('HASH', {
      event: 'open-widget-event-received-from-helpersimple',
      widgetId: id,
      timestamp: Date.now()
    })
    
    // Set flag to allow query-task-list to use initialQueryValue for selection
    // This ensures we only react to hash parameters when HelperSimple explicitly opens us
    // Using state instead of ref ensures React triggers re-render so query-task-list sees the change
    this.setState({ shouldUseInitialQueryValueForSelection: true }, () => {
      debugLogger.log('HASH-EXEC', {
        event: 'querysimple-flag-set-true-state-updated',
        widgetId: id,
        newState: {
          shouldUseInitialQueryValueForSelection: this.state.shouldUseInitialQueryValueForSelection,
          hasInitialQueryValue: !!this.state.initialQueryValue,
          initialQueryValueShortId: this.state.initialQueryValue?.shortId,
          initialQueryValueValue: this.state.initialQueryValue?.value
        },
        timestamp: Date.now()
      })
    })
    
    debugLogger.log('HASH', {
      event: 'shouldUseInitialQueryValueForSelection-flag-set-true',
      widgetId: id,
      flagValue: true,
      timestamp: Date.now()
    })
    
    // Now check URL parameters - HelperSimple has explicitly opened us
    this.urlConsumptionManager.checkUrlParameters(
      this.props,
      this.state.resultsMode,
      {
        onInitialValueFound: (value) => {
          if (value) {
            // Only update if the value or shortId has changed to avoid unnecessary re-renders
            const willUpdate = this.state.initialQueryValue?.shortId !== value.shortId || this.state.initialQueryValue?.value !== value.value
            
            debugLogger.log('HASH-EXEC', {
              event: 'querysimple-oninitialvaluefound-will-update',
              widgetId: this.props.id,
              willUpdate,
              previousShortId: this.state.initialQueryValue?.shortId,
              previousValue: this.state.initialQueryValue?.value,
              newShortId: value.shortId,
              newValue: value.value,
              timestamp: Date.now()
            })
            
            if (willUpdate) {
              debugLogger.log('HASH', {
                event: 'url-param-detected',
                widgetId: this.props.id,
                shortId: value.shortId,
                value: value.value,
                foundIn: 'manager',
                triggeredBy: 'helpersimple-open-widget-event',
                previousShortId: this.state.initialQueryValue?.shortId,
                previousValue: this.state.initialQueryValue?.value,
                timestamp: Date.now()
              })
              
              // Reset to New mode when hash parameter is detected to avoid bugs with accumulation modes
              // Using AccumulatedRecordsManager (r018.58)
              const needsModeReset = this.state.resultsMode !== SelectionType.NewSelection
              const currentMode = this.state.resultsMode
              
              // Update initialQueryValue state
              this.setState({ 
                initialQueryValue: { shortId: value.shortId, value: value.value }
              }, () => {
                debugLogger.log('HASH-EXEC', {
                  event: 'querysimple-initialqueryvalue-state-updated',
                  widgetId: this.props.id,
                  newState: {
                    shouldUseInitialQueryValueForSelection: this.state.shouldUseInitialQueryValueForSelection,
                    hasInitialQueryValue: !!this.state.initialQueryValue,
                    initialQueryValueShortId: this.state.initialQueryValue?.shortId,
                    initialQueryValueValue: this.state.initialQueryValue?.value,
                    resultsMode: this.state.resultsMode
                  },
                  timestamp: Date.now()
                })
              })

              // Reset mode via manager if needed
              if (needsModeReset) {
                const resetResult = this.accumulatedRecordsManager.resetModeOnHashDetection(
                  this.props.id,
                  currentMode
                )
                
                // Update widget state from manager's return value
                this.setState({
                  resultsMode: resetResult.resultsMode,
                  accumulatedRecords: resetResult.accumulatedRecords
                })
              }
            }
          } else {
            debugLogger.log('HASH-EXEC', {
              event: 'querysimple-oninitialvaluefound-no-value-clearing',
              widgetId: this.props.id,
              hasCurrentInitialQueryValue: !!this.state.initialQueryValue,
              timestamp: Date.now()
            })
            // No matching parameters found - clear state
            if (this.state.initialQueryValue) {
              this.setState({ initialQueryValue: undefined })
            }
          }
        },
        onModeResetNeeded: () => {
          // Reset to New mode when hash parameter is detected
          // Using AccumulatedRecordsManager (r018.58)
          const currentMode = this.state.resultsMode
          const needsReset = currentMode !== SelectionType.NewSelection
          
          if (needsReset) {
            debugLogger.log('HASH', {
              event: 'mode-reset-needed-on-hash-detection',
              widgetId: this.props.id,
              currentMode,
              triggeredBy: 'helpersimple-open-widget-event',
              timestamp: Date.now()
            })
            
            const resetResult = this.accumulatedRecordsManager.resetModeOnHashDetection(
              this.props.id,
              currentMode
            )
            
            // Update widget state from manager's return value
            this.setState({
              resultsMode: resetResult.resultsMode,
              accumulatedRecords: resetResult.accumulatedRecords
            })
          }
        }
      }
    )
  }

  componentDidMount() {
    // r027.000: Log initial theme mode on mount
    const initialThemeMode = (this.props as any).theme?.sys?.color?.mode
    if (initialThemeMode) {
      debugLogger.log('DARK-MODE', {
        action: 'initial-mode',
        widgetId: this.props.id,
        mode: initialThemeMode,
        isDark: initialThemeMode === 'dark'
      })
    }

    // Listen for HelperSimple's open widget event
    // QuerySimple should only process hash parameters when HelperSimple explicitly opens the widget
    // This ensures HelperSimple remains the orchestrator
    // Note: Event listener setup moved to parallel execution section below (Chunk 7.1)
    
    // Chunk 2: Manager implementation (r018.13 - Step 2.3: Switch to manager)
    if (this.widgetRef.current) {
      this.visibilityManager.setup(
        this.widgetRef.current,
        this.props,
        {
          onVisibilityChange: (isVisible) => {
            // Update state
            this.setState({ isPanelVisible: isVisible })
            
            // Handle restoration logic
            this.handleVisibilityChange(isVisible)
          }
        },
        (isVisible) => {
          // Manager's internal state tracking callback
          // (no-op, restoration handled in onVisibilityChange)
        }
      )
      
      // Notify mount via manager
      this.visibilityManager.notifyMount(this.props.id)
    }

    // Chunk 5: Initialize accumulated records manager state (r018.26 - Step 5.1: Add manager)
    // Sync manager state with widget state
    if (this.state.resultsMode) {
      this.accumulatedRecordsManager.handleResultsModeChange(
        this.props.id,
        this.state.resultsMode,
        false
      )
    }
    if (this.state.accumulatedRecords && this.state.accumulatedRecords.length > 0) {
      this.accumulatedRecordsManager.handleAccumulatedRecordsChange(
        this.props.id,
        this.state.accumulatedRecords
      )
    }
    
    // Set up callbacks for manager
    // Set up callbacks for manager (r018.57)
    // Note: Primary state updates come from manager return values in handleResultsModeChange/handleAccumulatedRecordsChange
    // These callbacks serve as backup/verification but shouldn't be needed since we update state directly from return values
    this.accumulatedRecordsManager.setCallbacks({
      onModeChange: (mode) => {
        // State is updated from handleResultsModeChange return value, so this is just a backup
        if (this.state.resultsMode !== mode) {
          this.setState({ resultsMode: mode })
        }
      },
      onAccumulatedRecordsChange: (records) => {
        // State is updated from handleAccumulatedRecordsChange, so this is just a backup
        const currentCount = this.state.accumulatedRecords?.length || 0
        if (currentCount !== records.length) {
          this.setState({ accumulatedRecords: records })
        }
      }
    })
    
    // Chunk 7: Event handling (r018.59 - Step 7.1: Add manager)
    this.eventManager.setHandlers({
      onOpenWidgetEvent: this.handleOpenWidgetEvent,
      // Chunk 3: Section 3.1 Step 3.1.5 (r019.5): Switch to manager implementation
      onSelectionChange: (event) => this.selectionRestorationManager.handleSelectionChange(event),
      onRestoreOnIdentifyClose: this.handleRestoreOnIdentifyClose
    })
    
    this.eventManager.setup(this.props.id)
    
    // Chunk 3: Selection & Restoration Manager (r019.2) - Section 3.1: Initialize widgetId
    this.selectionRestorationManager.setWidgetId(this.props.id)
    
    // Graphics layer will be initialized when map view becomes available via JimuMapViewComponent
    
    // Register widget config with HighlightConfigManager (r022.91)
    widgetConfigManager.registerConfig(this.props.id, this.props.config)
  }

  componentWillUnmount() {
    // r021.6 Chunk 2c: Close popup when widget unmounts
    const mapView = this.mapViewManager.getMapView() || this.mapViewRef.current
    if (mapView?.popup?.visible) {
      mapView.popup.close()
      debugLogger.log('POPUP', {
        event: 'popup-closed-on-widget-unmount',
        widgetId: this.props.id,
        reason: 'Widget unmounted',
        timestamp: Date.now()
      })
    }
    
    // r024.112: urlConsumptionManager.cleanup() removed — was a no-op.

    // Chunk 7: Event handling cleanup (r018.59 - Step 7.1: Add manager)
    this.eventManager.cleanup(this.props.id)
    
    // Chunk 2: Clean up manager (r018.13 - Step 2.3: Switch to manager)
    this.visibilityManager.cleanup()
    this.visibilityManager.notifyUnmount(this.props.id)
    
    // Chunk 4: Graphics layer cleanup (r018.25 - Step 4.3: Remove old implementation)
    this.graphicsLayerManager.cleanup(this.props.id)

    // r028.092: Path 3 FeatureLayer cleanup (gated by addResultsAsMapLayer)
    if (this.props.config?.addResultsAsMapLayer === true) {
      const unmountMapView = this.mapViewManager.getMapView() || this.mapViewRef.current
      if (unmountMapView) {
        void destroyResultLayers(this.props.id, unmountMapView as MapView)
      }
      clearRecordRegistry(this.props.id)
      clearQueryConfigs(this.props.id)
      // r028.044 (P4): Reset counters on unmount so stale state
      // doesn't accumulate across mount/unmount cycles.
      resetObjectIdCounter(this.props.id)
      resetKeyTracking(this.props.id)
      ;(this.resultGroupLayerRef as any).current = null
    }

    // r027.091: Hover-pin layer cleanup removed — hover pins now live on
    // mapView.graphics and are cleaned up per-graphic on card unmount.

    // Chunk 5: Clean up accumulated records manager (r018.26 - Step 5.1: Add manager)
    this.accumulatedRecordsManager.cleanup()
    
    // Unregister widget config from HighlightConfigManager (r022.91)
    widgetConfigManager.unregisterConfig(this.props.id)

    debugLogger.log('WIDGET-STATE', {
      event: 'widget-closed',
      widgetId: this.props.id,
      isOpen: false,
      timestamp: new Date().toISOString()
    })
  }

  componentDidUpdate(prevProps: AllWidgetProps<IMConfig>) {
    // QuerySimple no longer autonomously checks URL parameters
    // Only HelperSimple can trigger hash parameter processing via OPEN_WIDGET_EVENT
    // This ensures HelperSimple remains the orchestrator
    
    // r022.76: Watch props.state for ACTUAL close (not DOM visibility/minimize)
    // Uses official ExB state property instead of fragile DOM visibility detection
    if (prevProps.state !== this.props.state) {
      if (this.props.state === 'OPENED' && prevProps.state === 'CLOSED') {
        // Widget opened - restore selections
        debugLogger.log('WIDGET-STATE', {
          event: 'widget-opened-via-props-state',
          widgetId: this.props.id,
          prevState: prevProps.state,
          currentState: this.props.state,
          action: 'restore-selections',
          method: 'props.state-monitoring',
          note: 'r022.76: Official ExB state detection (not DOM visibility)',
          timestamp: Date.now()
        })
        
        // r022.76: Notify HelperSimple via event (replaces IntersectionObserver notification)
        const event = new CustomEvent('querysimple-widget-state-changed', {
          detail: {
            widgetId: this.props.id,
            isOpen: true
          },
          bubbles: true,
          cancelable: true
        })
        window.dispatchEvent(event)
        
        // r022.76: Restore selections on open
        this.handleVisibilityChange(true)
        
      } else if (this.props.state === 'CLOSED' && prevProps.state === 'OPENED') {
        // Widget closed - clear selections
        debugLogger.log('WIDGET-STATE', {
          event: 'widget-closed-via-props-state',
          widgetId: this.props.id,
          prevState: prevProps.state,
          currentState: this.props.state,
          action: 'clear-selections',
          method: 'props.state-monitoring',
          note: 'r022.76: Official ExB state detection (not DOM visibility)',
          timestamp: Date.now()
        })
        
        // r022.76: Notify HelperSimple via event (replaces IntersectionObserver notification)
        const event = new CustomEvent('querysimple-widget-state-changed', {
          detail: {
            widgetId: this.props.id,
            isOpen: false
          },
          bubbles: true,
          cancelable: true
        })
        window.dispatchEvent(event)
        
        // r022.76: Clear selections on close
        this.handleVisibilityChange(false)
      }
    }
    // Note: Minimize keeps state as 'OPENED', so no state change = no action = selections preserved ✓

    // r027.000: Detect theme mode changes (light ↔ dark) for ExB 1.20 dark mode support
    const prevThemeMode = (prevProps as any).theme?.sys?.color?.mode
    const currThemeMode = (this.props as any).theme?.sys?.color?.mode
    if (prevThemeMode !== currThemeMode && currThemeMode) {
      debugLogger.log('DARK-MODE', {
        action: 'theme-mode-changed',
        widgetId: this.props.id,
        previousMode: prevThemeMode || 'unknown',
        currentMode: currThemeMode,
        isDark: currThemeMode === 'dark'
      })
    }

    // Re-register config with HighlightConfigManager on config changes (r022.91)
    if (prevProps.config !== this.props.config) {
      widgetConfigManager.registerConfig(this.props.id, this.props.config)
      
      // r024.4: Detect addResultsAsMapLayer toggle change and reinitialize layer
      const prevAddResultsAsMapLayer = prevProps.config?.addResultsAsMapLayer === true
      const currAddResultsAsMapLayer = this.props.config?.addResultsAsMapLayer === true
      
      if (prevAddResultsAsMapLayer !== currAddResultsAsMapLayer) {
        // r024.4: Store mapView BEFORE cleanup (cleanup clears the ref)
        const mapView = this.mapViewManager.getMapView() || this.mapViewRef.current

        debugLogger.log('GRAPHICS-LAYER', {
          event: 'addResultsAsMapLayer-toggle-changed',
          widgetId: this.props.id,
          from: prevAddResultsAsMapLayer,
          to: currAddResultsAsMapLayer,
          action: 'reinitializing-layer',
          hasMapView: !!mapView,
          timestamp: Date.now()
        })

        // Cleanup existing layer
        this.graphicsLayerManager.cleanup(this.props.id)
        this.graphicsLayerRef.current = null

        // r028.008: Path 2 only — skip reinit when Path 3 FeatureLayers are active
        if (this.props.config?.addResultsAsMapLayer !== true && mapView) {
          void this.graphicsLayerManager.initialize(this.props.id, mapView, {
            onGraphicsLayerInitialized: (graphicsLayer) => {
              this.graphicsLayerRef.current = graphicsLayer
              this.setState({ graphicsLayerInitialized: true })
            }
          })
        }

        // r028.006: Rebuild Path 3 FeatureLayers on toggle change (if enabled)
        if (mapView && this.props.config?.addResultsAsMapLayer === true) {
          void destroyResultLayers(this.props.id, mapView as MapView).then(() => {
            // r028.044 (P4): Reset counters on rebuild so IDs start fresh
            resetObjectIdCounter(this.props.id)
            resetKeyTracking(this.props.id)
            ;(this.resultGroupLayerRef as any).current = null
            void this.initResultFeatureLayers(this.props.id, mapView as MapView)
          })
        }
      }

      // r028.092: Path 3 toggle-change cleanup (originally a useFeatureLayerResults
      // detector; after Phase 1 routing both toggle detectors gate on addResultsAsMapLayer).
      // The block above (r024.4) already handles graphics-layer init/cleanup and Path 3
      // rebuild on toggle ON. This block adds Path 3-specific state cleanup on toggle OFF
      // (registry, query configs, counters) that the block above doesn't do.
      // TODO: collapse these two blocks in Phase 3 (Path 2 deletion pass).
      const prevUseFLR = prevProps.config?.addResultsAsMapLayer === true
      const currUseFLR = this.props.config?.addResultsAsMapLayer === true
      if (prevUseFLR !== currUseFLR) {
        const mapView = this.mapViewManager.getMapView() || this.mapViewRef.current
        if (currUseFLR && mapView) {
          void this.initResultFeatureLayers(this.props.id, mapView as MapView)
        } else if (!currUseFLR && mapView) {
          void destroyResultLayers(this.props.id, mapView as MapView)
          clearRecordRegistry(this.props.id)
          clearQueryConfigs(this.props.id)
          // r028.044 (P4): Reset counters on toggle-off
          resetObjectIdCounter(this.props.id)
          resetKeyTracking(this.props.id)
          ;(this.resultGroupLayerRef as any).current = null
        }
      }

      // r028.005: Detect symbology config changes and update FeatureLayer renderers
      if (this.props.config?.addResultsAsMapLayer === true) {
        const symbologyFields = [
          'highlightFillColor', 'highlightFillOpacity',
          'highlightOutlineColor', 'highlightOutlineOpacity', 'highlightOutlineWidth',
          'highlightPointSize', 'highlightPointOutlineWidth', 'highlightPointStyle'
        ] as const
        const symbologyChanged = symbologyFields.some(
          f => prevProps.config?.[f] !== this.props.config?.[f]
        )
        if (symbologyChanged) {
          this.updateResultFeatureLayerRenderers()
        }
      }

      // r028.004: Update popup query configs when queryItems change
      if (this.props.config?.addResultsAsMapLayer === true) {
        const queryItems = this.props.config?.queryItems?.asMutable?.({ deep: true }) || []
        setQueryConfigs(this.props.id, queryItems)
      }
    }
    
    // Chunk 4: Graphics layer is now required (r018.25 - Step 4.3: Remove config change handling)
    // No need to handle config changes for graphics layer since it's always enabled
  }

  /**
   * Notifies HelperSimple widget of selection changes via custom event.
   * 
   * This method dispatches a custom event that HelperSimple listens to for tracking
   * selection state. Called by QueryTaskResult component when user selects records.
   * 
   * @param recordIds - Array of selected record IDs (objectIds from the feature layer)
   * @param dataSourceId - Optional data source ID for the selected records
   * 
   * @since 1.19.0-r017.0
   */
  notifyHelperSimpleOfSelection = (recordIds: string[], dataSourceId?: string) => {
    const { id } = this.props
    
    // Chunk 7: Dispatch selection event via EventManager (r018.59)
    // Note: This call is missing outputDsId and queryItemConfigId, but this method
    // is only used for notifying HelperSimple (r021.110: lastSelection removed).
    // The actual selection events come from query-task.tsx and query-result.tsx
    // which use dispatchSelectionEvent from selection-utils.ts
    this.eventManager.dispatchSelectionEvent(id, recordIds, dataSourceId)
  }

  /**
   * Handles widget panel visibility changes from WidgetVisibilityManager.
   * 
   * This method implements the selection restoration pattern:
   * - When panel opens: Restores selection to map if widget has accumulated records or last selection
   * - When panel closes: Clears selection from map (but preserves widget state for restoration)
   * 
   * The restoration logic respects the current results mode:
   * - "Add to" / "Remove from" modes: Uses accumulated records for restoration
   * - "New" mode: Uses accumulated records (r021.110: lastSelection removed)
   * 
   * @param isVisible - True if widget panel is visible, false if hidden
   * 
   * @since 1.19.0-r018.13 (Chunk 2: Manager implementation)
   * @see {@link WidgetVisibilityManager} for visibility detection implementation
   */
  handleVisibilityChange = (isVisible: boolean) => {
    if (isVisible) {
      // When panel opens, check if we have selection to restore
      const isAccumulationMode = this.state.resultsMode === SelectionType.AddToSelection || 
                                 this.state.resultsMode === SelectionType.RemoveFromSelection
      const hasAccumulatedRecords = this.state.accumulatedRecords && this.state.accumulatedRecords.length > 0
      const hasSelectionState = this.state.hasSelection || false
      const hasSelectionToRestore = isAccumulationMode 
        ? hasAccumulatedRecords 
        : hasSelectionState
      
      debugLogger.log('RESTORE', {
        event: 'panel-opened-checking-selection',
        widgetId: this.props.id,
        resultsMode: this.state.resultsMode,
        isAccumulationMode,
        hasSelection: hasSelectionState,
        hasAccumulatedRecords,
        accumulatedRecordsCount: this.state.accumulatedRecords?.length || 0,
        selectionRecordCount: this.state.selectionRecordCount || 0,
        hasSelectionToRestore,
        decisionLogic: {
          'isAccumulationMode': isAccumulationMode,
          'hasAccumulatedRecords': hasAccumulatedRecords,
          'hasSelectionState': hasSelectionState,
          'calculated-hasSelectionToRestore': hasSelectionToRestore,
          'will-call-addSelectionToMap': hasSelectionToRestore
        }
      })
      
      // Add selection to map if we have one
      if (hasSelectionToRestore) {
        // r020.1 (BUG-HASH-DIRTY-001): Safety check - only restore if we have records to display
        // r027.079: accumulatedRecords stores FeatureDataRecord[] directly post-r027.072.
        // The previous `.some(ar => ar.record)` was a vestige of the {configId, record}
        // wrapper shape — `ar.record` has been undefined since the wrapper was dropped,
        // making that branch silently always-false (the selectionRecordCount fallback
        // was masking it). Length check matches the pre-r027.072 truthy semantics.
        const hasRecordsToDisplay = !!this.state.accumulatedRecords?.length ||
                                    this.state.selectionRecordCount > 0
        
        if (!hasRecordsToDisplay) {
          debugLogger.log('RESTORE', {
            event: 'panel-opened-skipping-restore-no-records',
            widgetId: this.props.id,
            reason: 'hasSelectionToRestore-true-but-no-records-to-display',
            hasAccumulatedRecords,
            accumulatedRecordsCount: this.state.accumulatedRecords?.length || 0,
            selectionRecordCount: this.state.selectionRecordCount || 0
          })
          return // Don't restore if no records
        }
        
        debugLogger.log('RESTORE', {
          event: 'panel-opened-calling-addSelectionToMap',
          widgetId: this.props.id,
          reason: 'hasSelectionToRestore-is-true'
        })
        ;(async () => {
          const deps = {
            graphicsLayerRef: this.graphicsLayerRef,
            mapViewRef: this.mapViewRef,
            graphicsLayerManager: this.graphicsLayerManager,
            config: this.props.config
          }
          await this.selectionRestorationManager.addSelectionToMap(deps)
        })()
      } else {
        debugLogger.log('RESTORE', {
          event: 'panel-opened-skipping-addSelectionToMap',
          widgetId: this.props.id,
          reason: 'hasSelectionToRestore-is-false',
          why: isAccumulationMode 
            ? 'no-accumulated-records' 
            : 'no-hasSelection-state'
        })
      }
    } else {
      // r021.7 Chunk 2c: Close popup when widget panel closes
      // r024.58: Skip on LL path - graphics persist, so popup content is still valid
      const isLayerListMode = this.props.config?.addResultsAsMapLayer === true
      const mapView = this.mapViewManager.getMapView() || this.mapViewRef.current
      if (!isLayerListMode && mapView?.popup?.visible) {
        mapView.popup.close()
        debugLogger.log('POPUP', {
          event: 'popup-closed-on-panel-close',
          widgetId: this.props.id,
          reason: 'Widget panel closed (non-LL mode)',
          timestamp: Date.now()
        })
      }
      
      // When panel closes, clear selection from map only (keep widget state)
      const isAccumulationMode = this.state.resultsMode === SelectionType.AddToSelection || 
                                 this.state.resultsMode === SelectionType.RemoveFromSelection
      const hasAccumulatedRecords = this.state.accumulatedRecords && this.state.accumulatedRecords.length > 0
      const hasSelectionState = this.state.hasSelection || false
      const hasSelectionToClear = isAccumulationMode 
        ? hasAccumulatedRecords 
        : hasSelectionState
      
      debugLogger.log('RESTORE', {
        event: 'panel-closed-checking-selection',
        widgetId: this.props.id,
        resultsMode: this.state.resultsMode,
        isAccumulationMode,
        hasSelection: hasSelectionState,
        hasAccumulatedRecords,
        accumulatedRecordsCount: this.state.accumulatedRecords?.length || 0,
        selectionRecordCount: this.state.selectionRecordCount || 0,
        hasSelectionToClear,
        decisionLogic: {
          'isAccumulationMode': isAccumulationMode,
          'hasAccumulatedRecords': hasAccumulatedRecords,
          'hasSelectionState': hasSelectionState,
          'calculated-hasSelectionToClear': hasSelectionToClear,
          'will-call-clearSelectionFromMap': hasSelectionToClear
        }
      })
      
      if (hasSelectionToClear) {
        debugLogger.log('RESTORE', {
          event: 'panel-closed-calling-clearSelectionFromMap',
          widgetId: this.props.id,
          reason: 'hasSelectionToClear-is-true'
        })
        ;(async () => {
          const deps = {
            graphicsLayerRef: this.graphicsLayerRef,
            mapViewRef: this.mapViewRef,
            graphicsLayerManager: this.graphicsLayerManager,
            config: this.props.config
          }
          await this.selectionRestorationManager.clearSelectionFromMap(deps)
        })()
      } else {
        debugLogger.log('RESTORE', {
          event: 'panel-closed-no-selection-to-clear',
          widgetId: this.props.id,
          reason: 'hasSelectionToClear-is-false',
          why: isAccumulationMode 
            ? 'no-accumulated-records' 
            : 'no-hasSelection-state'
        })
      }
    }
  }



  /**
   * Handles map view change from JimuMapViewComponent.
   *
   * This method is called by JimuMapViewComponent when the map view becomes available
   * or changes. It delegates to MapViewManager for reference management and initializes
   * the graphics layer if enabled in widget configuration.
   *
   * @param jimuMapView - The JimuMapView instance from JimuMapViewComponent, or null if unavailable
   *
   * @since 1.19.0-r018.18 (Chunk 6: Manager implementation)
   * @see {@link MapViewManager} for map view reference management
   */
  private handleJimuMapViewChanged = (jimuMapView: JimuMapView | null) => {
    const { id, config } = this.props
    
    // Manager implementation (r018.16 - Step 6.3: Switch to manager)
    this.mapViewManager.handleJimuMapViewChanged(
      jimuMapView,
      this.props,
      {
        onMapViewChange: (newJimuMapView) => {
          // Get map view from manager
          const newMapView = this.mapViewManager.getMapView()

          // r021.19: Store mapView in ref so it's available to QueryTask
          this.mapViewRef.current = newMapView

          // r025.041: Store JimuMapView in state for spatial Draw mode (JimuDraw component)
          this.setState({ jimuMapView: newJimuMapView })
          
          // Chunk 4: Graphics layer initialization (r018.25 - Step 4.3: Remove old implementation)
          // r028.008: Path 2 only — skip when Path 3 FeatureLayers are active
          if (config?.addResultsAsMapLayer !== true && this.graphicsLayerManager.shouldInitialize(config, newMapView) && newMapView) {
            // Use void to handle promise without blocking
            void this.graphicsLayerManager.initialize(id, newMapView, {
              onGraphicsLayerInitialized: (graphicsLayer) => {
                // r021.19: Store graphics layer in ref
                this.graphicsLayerRef.current = graphicsLayer
                // Update state to force re-render and update props
                this.setState({ graphicsLayerInitialized: true })
              }
            })
          }

          // r028.092: Path 3 FeatureLayer init (gated by addResultsAsMapLayer)
          if (newMapView && config?.addResultsAsMapLayer === true) {
            void this.initResultFeatureLayers(id, newMapView as MapView)
          }
        }
      }
    )
  }

  /**
   * r028.004: Create Path 3 GroupLayer and register query configs for popup rendering.
   */
  private async initResultFeatureLayers (widgetId: string, mapView: MapView): Promise<void> {
    try {
      const groupLayer = await createResultGroupLayer(widgetId, mapView)
      ;(this.resultGroupLayerRef as any).current = groupLayer

      const queryItems = this.props.config?.queryItems?.asMutable?.({ deep: true }) || []
      setQueryConfigs(widgetId, queryItems)

      debugLogger.log('FEATURE-LAYER', {
        event: 'initResultFeatureLayers',
        widgetId,
        groupLayerId: groupLayer.id,
        queryConfigCount: queryItems.length
      })
    } catch (err) {
      debugLogger.log('FEATURE-LAYER', {
        event: 'initResultFeatureLayers-error',
        widgetId,
        error: err instanceof Error ? err.message : 'Unknown'
      })
    }
  }

  /**
   * r028.005: Swap renderers on existing FeatureLayers when symbology config changes.
   */
  private updateResultFeatureLayerRenderers (): void {
    const groupLayer = this.resultGroupLayerRef.current
    if (!groupLayer) return

    const children = (groupLayer as any).layers?.toArray?.() || []
    for (const layer of children) {
      const geometryType = (layer as any).geometryType
      if (geometryType) {
        updateFeatureLayerRenderer(layer, geometryType, this.props.id)
      }
    }

    debugLogger.log('FEATURE-LAYER', {
      event: 'updateResultFeatureLayerRenderers',
      widgetId: this.props.id,
      layersUpdated: children.length
    })
  }

  /**
   * Initializes graphics layer lazily when output data source becomes available.
   *
   * This method is called by QueryTask component when an output data source is created.
   * It retrieves the map view from MapViewManager and initializes the graphics layer
   * using GraphicsLayerManager if not already initialized.
   * 
   * @param outputDS - The output data source that was created
   * 
   * @since 1.19.0-r017.0
   * @see {@link GraphicsLayerManager.initializeFromOutputDS} for graphics layer initialization
   * @see {@link MapViewManager.getMapView} for map view retrieval
   */
  public initializeGraphicsLayerFromOutputDS = async (outputDS: DataSource) => {
    const { id, config } = this.props

    // r028.008: Path 2 only — skip when Path 3 FeatureLayers are active
    if (config?.addResultsAsMapLayer === true) return

    // Chunk 4: Graphics layer initialization (r018.25 - Step 4.3: Remove old implementation)
    // Use map view from manager if available
    const mapView = this.mapViewManager.getMapView() || this.mapViewRef.current

    await this.graphicsLayerManager.initializeFromOutputDS(
      id,
      config,
      outputDS,
      mapView,
      {
        onGraphicsLayerInitialized: (graphicsLayer) => {
          this.setState({ graphicsLayerInitialized: true })
        }
      }
    )
  }


  /**
   * Clears all graphics from the graphics layer if it exists.
   * 
   * This method is called when clearing results or switching queries in "New" mode
   * to ensure graphics are removed from the map. It does not remove the graphics layer
   * itself, only clears its contents.
   * 
   * @since 1.19.0-r017.0
   * @see {@link GraphicsLayerManager.clearGraphics} for graphics clearing logic
   */
  public clearGraphicsLayerIfExists = () => {
    const { config } = this.props
    
    // Chunk 4: Graphics layer clearing (r018.25 - Step 4.3: Remove old implementation)
    this.graphicsLayerManager.clearGraphics(this.props.id, config)
  }

  /**
   * Clears graphics layer refs after layer has been destroyed, then recreates the layer.
   * 
   * This method is called after cleanupGraphicsLayer() destroys the layer.
   * It immediately recreates the layer so it's available for the next query.
   * 
   * @since 1.19.0-r021.19 (Option 2: Immediate recreation)
   * @see {@link clearGraphicsLayerIfExists} for clearing graphics without destroying layer
   */
  public clearGraphicsLayerRefs = async () => {
    const mapView = this.mapViewRef.current
    const { id } = this.props

    // r028.008: Path 2 only — skip when Path 3 FeatureLayers are active
    if (this.props.config?.addResultsAsMapLayer === true) return

    debugLogger.log('GRAPHICS-LAYER', {
      event: 'clearGraphicsLayerRefs-called',
      widgetId: id,
      hasMapView: !!mapView,
      willRecreate: !!mapView,
      timestamp: Date.now()
    })

    // Clear old refs
    this.graphicsLayerRef.current = null

    // r027.089 Site C+D (atomic): Delegate to graphicsLayerManager.initialize()
    // instead of duplicating layer-creation logic inline. The manager owns
    // useGroupLayer mode: it sets graphicsLayerRef.current to the inner
    // GraphicsLayer and tracks the parent GroupLayer on its private field.
    // Render-prop sites now read manager.getResultsLayer() (Site D), which
    // returns the GroupLayer parent in useGroupLayer mode, so legend-aware
    // consumers continue to receive the correct layer. This eliminates the
    // dual inline/manager layer-creation paths that produced the r027.085
    // and r027.087 legend regressions.
    if (mapView) {
      try {
        const newLayer = await this.graphicsLayerManager.initialize(id, mapView)

        debugLogger.log('GRAPHICS-LAYER', {
          event: 'clearGraphicsLayerRefs-recreated',
          widgetId: id,
          newLayerId: newLayer?.id,
          useGroupLayer: widgetConfigManager.getAddResultsAsMapLayer(id),
          timestamp: Date.now()
        })

        // Force re-render to pass new layer down
        this.setState({ graphicsLayerInitialized: true })
      } catch (error) {
        debugLogger.log('GRAPHICS-LAYER', {
          event: 'clearGraphicsLayerRefs-recreation-failed',
          widgetId: id,
          error: error instanceof Error ? error.message : String(error),
          timestamp: Date.now()
        })
      }
    }
  }



  /**
   * Handles selection change events from QueryTaskResult component.
   * 
   * This method updates widget state when records are selected or deselected in the
   * results tab. It respects the current results mode:
   * - "Add to" / "Remove from" modes: Uses accumulated records count for restoration state
   * - "New" mode: Uses event record IDs for restoration state
   * 
   * Also handles automatic mode reset: If selection is cleared in "Remove from" mode,
   * the mode is automatically reset to "New" since Remove mode requires selection to function.
   * 
   * @param event - Custom event containing selection details (widgetId, recordIds, outputDsId, queryItemConfigId)
   * 
   * @since 1.19.0-r017.0
   */

  /**
   * Handles restore request when identify popup closes.
   * 
   * This method restores selection to the map after the identify popup closes.
   * It only restores if the widget panel is currently open and accumulated records exist.
   * 
   * r022.42: Simplified to use shared addSelectionToMap() path (same as componentDidShow)
   * with manageGraphicsLayer=false to skip graphics clear/re-add (graphics already visible).
   * 
   * @param event - Custom event dispatched by HelperSimple (widgetId, timestamp)
   * 
   * @since 1.19.0-r017.0
   * @see {@link RESTORE_ON_IDENTIFY_CLOSE_EVENT} for event name constant
   */
  private handleRestoreOnIdentifyClose = (event: Event) => {
    const customEvent = event as CustomEvent<{ 
      widgetId: string,
      timestamp: string
    }>
    const { id } = this.props
    
    // Only handle if this is for our widget
    if (customEvent.detail.widgetId !== id) {
      return
    }
    
    // r022.93: Trust props.state if available (minimized widgets still 'OPENED')
    // Fallback to DOM visibility only if props.state is undefined (initial load)
    const isWidgetOpen = this.props.state === 'OPENED' || 
                         (this.props.state === undefined && this.visibilityManager.getIsPanelVisible())
    
    // r022.42: Simplified logging - no more per-layer event details
    debugLogger.log('RESTORE', {
      event: 'identify-popup-closed-restore-requested',
      widgetId: id,
      isWidgetOpen,
      propsState: this.props.state,
      domVisible: this.visibilityManager.getIsPanelVisible(),
      resultsMode: this.state.resultsMode,
      hasAccumulatedRecords: !!(this.state.accumulatedRecords && this.state.accumulatedRecords.length > 0),
      accumulatedRecordsCount: this.state.accumulatedRecords?.length || 0,
      note: 'r022.93: Trust props.state OPENED (even if minimized), fallback to DOM if undefined',
      timestamp: customEvent.detail.timestamp
    })
    
    // Only restore if widget is open
    if (!isWidgetOpen) {
      debugLogger.log('RESTORE', {
        event: 'identify-popup-closed-restore-skipped-widget-closed',
        widgetId: id,
        propsState: this.props.state,
        domVisible: this.visibilityManager.getIsPanelVisible(),
        decision: 'SKIP_RESTORATION',
        reason: 'Widget is closed'
      })
      return
    }
    
    // r022.42: Check if accumulated records exist (universal for ALL modes)
    if (!this.state.accumulatedRecords || this.state.accumulatedRecords.length === 0) {
      debugLogger.log('RESTORE', {
        event: 'identify-popup-closed-restore-skipped-no-accumulated-records',
        widgetId: id,
        resultsMode: this.state.resultsMode,
        decision: 'SKIP_RESTORATION',
        reason: 'No accumulated records to restore'
      })
      return
    }
    
    // r022.42: Use shared restoration path (same as componentDidShow) with manageGraphicsLayer=false
    debugLogger.log('RESTORE', {
      event: 'identify-popup-closed-restoring-via-shared-path',
      widgetId: id,
      resultsMode: this.state.resultsMode,
      accumulatedRecordsCount: this.state.accumulatedRecords.length,
      manageGraphicsLayer: false,
      note: 'r022.42: Using shared addSelectionToMap() with graphics management disabled'
    })
    
    ;(async () => {
      const deps = {
        graphicsLayerRef: this.graphicsLayerRef,
        mapViewRef: this.mapViewRef,
        graphicsLayerManager: this.graphicsLayerManager,
        config: this.props.config
      }
      await this.selectionRestorationManager.addSelectionToMap(deps, false) // r022.42: false = skip graphics management
    })()
  }

  // ============================================================================
  // r019.18: Removed addSelectionToMapParallel wrapper (27 lines)
  // r019.20: Removed clearSelectionFromMapParallel wrapper (27 lines)
  // All call sites now directly invoke SelectionRestorationManager methods
  // ============================================================================

  // ============================================================================
  // r019.15: Removed old addSelectionToMap implementation (272 lines)
  // Now fully handled by SelectionRestorationManager.addSelectionToMap()
  // ============================================================================

  /**
   * Handles results mode change from the mode dropdown in QueryTask component.
   * 
   * This method is called when the user switches between "Create new", "Add to", or
   * "Remove from" modes. It performs the following actions:
   * 
   * 1. Consumes hash parameters when switching to accumulation modes (prevents re-triggering)
   * 2. Clears accumulated records when switching to "New" mode
   * 3. Updates widget state with the new mode
   * 
   * @param mode - The new selection type mode (NewSelection, AddToSelection, or RemoveFromSelection)
   * 
   * @since 1.19.0-r017.0
   */
  private handleResultsModeChange = (mode: SelectionType) => {
    // Using AccumulatedRecordsManager (r018.58)
    const shouldConsumeHash = (mode === SelectionType.AddToSelection || mode === SelectionType.RemoveFromSelection) && !!this.state.initialQueryValue?.shortId
    
    const result = this.accumulatedRecordsManager.handleResultsModeChange(
      this.props.id,
      mode,
      shouldConsumeHash,
      this.state.initialQueryValue?.shortId,
      this.removeHashParameter
    )

    // Reset manual modifications when switching to New Selection mode
    if (mode === SelectionType.NewSelection && this.state.resultsMode !== SelectionType.NewSelection) {
      this.resetManualModifications()
    }

    // Update widget state from manager's return value
    this.setState({
      resultsMode: result.resultsMode,
      accumulatedRecords: result.accumulatedRecords
    })
  }

  /**
   * Removes a hash parameter from the URL when switching to accumulation modes.
   * 
   * This method is called when switching to "Add to" or "Remove from" modes to consume
   * the deep link parameter. This prevents the hash parameter from re-triggering the query
   * when the widget re-renders.
   * 
   * The URL is updated using history.replaceState to avoid page reload, and both pathname
   * and query string are preserved (e.g., debug parameters remain intact).
   * 
   * @param shortId - The shortId parameter to remove from the URL hash
   * 
   * @since 1.19.0-r017.0
   */
  private removeHashParameter = (shortId: string) => {
    if (!shortId) return

    if (removeHashParam(shortId)) {
      // Clear the state so it won't trigger again
      if (this.state.initialQueryValue?.shortId === shortId) {
        this.setState({ initialQueryValue: undefined })
      }
    }
  }

  private handleAccumulatedRecordsChange = (records: FeatureDataRecord[]) => {
    const previousRecords = this.state.accumulatedRecords || []
    const previousCount = previousRecords.length
    const newCount = records.length
    
    // r024.23: Optimize logging to avoid creating arrays on clear path
    // Each .map() and .filter() creates a new array, contributing to 400K+ array accumulation
    if (newCount > 0 || previousCount > 0) {
      // Only compute IDs when there's something to log (non-empty case)
      // r027.000: ExB 1.20 — coerce getId() to string (now returns string | number)
      const previousIds = previousCount > 0 ? previousRecords.map(r => String(r.getId())) : []
      const newIds = newCount > 0 ? records.map(r => String(r.getId())) : []
      
      debugLogger.log('RESULTS-MODE', {
        event: 'accumulated-records-state-change',
        widgetId: this.props.id,
        previousCount,
        previousIds: previousIds.slice(0, 20), // Limit to 20 for log readability
        newCount,
        newIds: newIds.slice(0, 20),
        resultsMode: this.state.resultsMode,
        timestamp: Date.now()
      })
    }
    
    // Using AccumulatedRecordsManager (r018.58)
    this.accumulatedRecordsManager.handleAccumulatedRecordsChange(this.props.id, records)

    // If we're in Remove mode and all accumulated records are cleared, reset to NewSelection mode
    // Remove mode requires accumulated records to function, so it should be disabled when records are empty
    const shouldResetMode = newCount === 0 && 
                           this.state.resultsMode === SelectionType.RemoveFromSelection

    // r024.23: Only capture stack trace for debugging when needed
    const stackTrace = (previousCount > 0 || newCount > 0) 
      ? (new Error().stack?.split('\n').slice(2, 6).join(' << ') || 'unknown')
      : 'clear-path'
    
    // r024.74: Calculate extent once when records change (for zoom/pan actions)
    const resultsExtent = records.length > 0 ? calculateRecordsExtent(records) : null
    
    debugLogger.log('ZOOM', {
      event: 'resultsExtent-calculated-on-accumulation-change',
      widgetId: this.props.id,
      recordsCount: records.length,
      hasExtent: !!resultsExtent,
      extent: resultsExtent ? {
        xmin: resultsExtent.xmin,
        xmax: resultsExtent.xmax,
        ymin: resultsExtent.ymin,
        ymax: resultsExtent.ymax,
        width: resultsExtent.width,
        height: resultsExtent.height
      } : null,
      timestamp: Date.now()
    })
    
    this.setState({ 
      accumulatedRecords: records,
      resultsExtent,
      // Reset mode to NewSelection if all accumulated records cleared in Remove mode
      ...(shouldResetMode ? {
        resultsMode: SelectionType.NewSelection
      } : {})
    }, () => {
      debugLogger.log('WIDGET-STATE', {
        event: 'widget-updated-accumulated-records',
        widgetId: this.props.id,
        beforeCount: previousCount,
        afterCount: this.state.accumulatedRecords?.length || 0,
        expectedCount: records.length,
        match: this.state.accumulatedRecords?.length === records.length,
        willResetMode: shouldResetMode,
        calledFrom: stackTrace,
        timestamp: Date.now()
      })
    })

    if (shouldResetMode) {
      debugLogger.log('RESULTS-MODE', {
        event: 'mode-reset-on-accumulated-records-cleared',
        widgetId: this.props.id,
        previousMode: SelectionType.RemoveFromSelection,
        newMode: SelectionType.NewSelection,
        reason: 'all-accumulated-records-cleared-in-remove-mode',
        timestamp: Date.now()
      })
    }

    // r028.092: Sync Path 3 FeatureLayers (gated by addResultsAsMapLayer)
    if (this.props.config?.addResultsAsMapLayer === true) {
      void this.syncResultFeatureLayers(records, previousRecords)
    }
  }

  /**
   * r028.004: Diff accumulated records against FeatureLayer state and apply adds/removes.
   * r028.087: Wrapped by the serializer so concurrent invocations queue FIFO rather than
   * interleaving read-modify-write against the shared _keysByWidget Set.
   */
  private syncResultFeatureLayers (
    records: FeatureDataRecord[],
    previousRecords: FeatureDataRecord[]
  ): Promise<void> {
    return this.syncResultFeatureLayersSerializer(
      () => this.doSyncResultFeatureLayers(records, previousRecords)
    )
  }

  /**
   * r028.087: Actual sync body — wrapped by syncResultFeatureLayers via the serializer.
   * Do not call directly; always go through syncResultFeatureLayers.
   */
  private async doSyncResultFeatureLayers (
    records: FeatureDataRecord[],
    previousRecords: FeatureDataRecord[]
  ): Promise<void> {
    const groupLayer = this.resultGroupLayerRef.current
    if (!groupLayer) return

    const widgetId = this.props.id

    try {
      if (records.length === 0 && previousRecords.length > 0) {
        await clearResultFeatures(groupLayer, widgetId)
        debugLogger.log('FEATURE-LAYER', {
          event: 'syncResultFeatureLayers-cleared',
          widgetId,
          previousCount: previousRecords.length
        })
        return
      }

      const existingKeys = getExistingCompositeKeys(widgetId)

      // Build new keys from incoming records
      const newKeyToRecord = new Map<string, { record: FeatureDataRecord, configId: string }>()
      for (const record of records) {
        const configId = (record as any).feature?.attributes?.__queryConfigId || ''
        const recordId = String(record.getId())
        const key = buildCompositeKey(configId, recordId)
        newKeyToRecord.set(key, { record, configId })
      }

      // Remove features no longer in accumulated records
      const keysToRemove = [...existingKeys].filter(k => !newKeyToRecord.has(k))
      if (keysToRemove.length > 0) {
        await removeResultFeatures(groupLayer, keysToRemove, widgetId)
      }

      // Add features not yet on the map, grouped by configId
      const byConfig = new Map<string, FeatureDataRecord[]>()
      for (const [key, { record, configId }] of newKeyToRecord) {
        if (existingKeys.has(key)) continue
        if (!byConfig.has(configId)) byConfig.set(configId, [])
        byConfig.get(configId)!.push(record)
      }

      for (const [configId, configRecords] of byConfig) {
        await addResultFeatures(groupLayer, configRecords, configId, widgetId)
      }

      debugLogger.log('FEATURE-LAYER', {
        event: 'syncResultFeatureLayers',
        widgetId,
        existingCount: existingKeys.size,
        removed: keysToRemove.length,
        addedConfigs: byConfig.size,
        totalRecords: records.length
      })
    } catch (err) {
      debugLogger.log('FEATURE-LAYER', {
        event: 'syncResultFeatureLayers-error',
        widgetId,
        error: err instanceof Error ? err.message : 'Unknown'
      })
    }
  }

  /**
   * NOTE: No longer needed - we use existing output DS instead of creating new one.
   * Kept for reference but not used.
   */
  private getOrCreateAccumulatedResultsDS = async (originDS: FeatureLayerDataSource): Promise<FeatureLayerDataSource> => {
    // This is no longer used - we merge records into existing output DS
    throw new Error('This method is deprecated - use existing output DS instead')
  }

  // ============================================================================
  // r019.16: Removed old clearSelectionFromMap implementation (355 lines)
  // Now fully handled by SelectionRestorationManager.clearSelectionFromMap()
  // ============================================================================

  /**
   * NOTIFY that a hash parameter has been used.
   * Previously this removed the hash from the URL, but per updated requirements,
   * user-entered hashes should remain in the URL.
   * 
   * @param shortId - The shortId parameter that was used
   */
  handleHashParameterUsed = (shortId: string) => {
    const { id } = this.props
    const { initialQueryValue } = this.state
    
    debugLogger.log('HASH-EXEC', {
      event: 'querysimple-handlehashparameterused-called',
      widgetId: id,
      shortId,
      currentState: {
        shouldUseInitialQueryValueForSelection: this.state.shouldUseInitialQueryValueForSelection,
        hasInitialQueryValue: !!this.state.initialQueryValue,
        initialQueryValueShortId: this.state.initialQueryValue?.shortId,
        initialQueryValueValue: this.state.initialQueryValue?.value
      },
      timestamp: Date.now()
    })
    
    // NOTE: Hash parameters are NOT cleared here - they persist in URL
    // Hash parameters are only consumed when switching to accumulation modes (Add/Remove)
    // to prevent re-triggering when the user manually switches modes
    
    debugLogger.log('HASH', {
      event: 'handleHashParameterUsed-notified',
      widgetId: id,
      shortId: shortId,
      currentInitialQueryValue: initialQueryValue,
      note: 'Hash parameter used but NOT cleared - hash remains in URL per user requirement',
      timestamp: Date.now()
    })
    
    // ALWAYS clear both hash state values after execution
    // QuerySimple should not remember hash state after HelperSimple-driven execution completes
    // This prevents autonomous re-processing when switching queries
    // Using a single setState ensures atomic update and prevents race conditions
    this.setState({ 
      shouldUseInitialQueryValueForSelection: false,
      initialQueryValue: undefined
    }, () => {
      debugLogger.log('HASH-EXEC', {
        event: 'querysimple-handlehashparameterused-state-cleared',
        widgetId: id,
        shortId,
        newState: {
          shouldUseInitialQueryValueForSelection: this.state.shouldUseInitialQueryValueForSelection,
          hasInitialQueryValue: !!this.state.initialQueryValue,
          initialQueryValueShortId: this.state.initialQueryValue?.shortId,
          initialQueryValueValue: this.state.initialQueryValue?.value
        },
        timestamp: Date.now()
      })
    })
    
    debugLogger.log('HASH', {
      event: 'shouldUseInitialQueryValueForSelection-flag-cleared',
      widgetId: id,
      shortId: shortId,
      flagValue: false,
      timestamp: Date.now()
    })
  }


  render () {
    const { config, id, icon, label, layoutId, layoutItemId, controllerWidgetId } = this.props
    const widgetLabel = this.props.intl.formatMessage({
      id: '_widgetLabel',
      defaultMessage: defaultMessages._widgetLabel
    })
    // r028.060: SETTINGS log for widget-level config
    debugLogger.log('SETTINGS', {
      event: 'singletonConfigRead',
      source: 'widget',
      widgetId: id,
      showHeader: widgetConfigManager.getShowHeader(id),
      addResultsAsMapLayer: widgetConfigManager.getAddResultsAsMapLayer(id),
      resultsLayerTitle: widgetConfigManager.getResultsLayerTitle(id)
    })

    if (!config.queryItems?.length) {
      return <WidgetPlaceholder icon={iconMap.iconQuery} widgetId={this.props.id} name={widgetLabel} />
    }

    if (config.arrangeType === QueryArrangeType.Popper && !controllerWidgetId) {
      return (
        <QueryWidgetContext.Provider value={`${layoutId}:${layoutItemId}`}>
          <TaskListPopperWrapper
            id={0}
            icon={icon}
            popperTitle={label}
            minSize={config.sizeMap?.arrangementIconPopper?.minSize}
            defaultSize={config.sizeMap?.arrangementIconPopper?.defaultSize}
          >
              <QueryTaskList
                widgetId={id}
                isInPopper
                queryItems={config.queryItems}
                className='pb-4'
                initialQueryValue={this.state.initialQueryValue}
                shouldUseInitialQueryValueForSelection={this.state.shouldUseInitialQueryValueForSelection}
                onHashParameterUsed={this.handleHashParameterUsed}
                resultsMode={this.state.resultsMode}
                onResultsModeChange={this.handleResultsModeChange}
                accumulatedRecords={this.state.accumulatedRecords}
                resultsExtent={this.state.resultsExtent}
                onAccumulatedRecordsChange={this.handleAccumulatedRecordsChange}
                graphicsLayer={this.graphicsLayerManager.getResultsLayer() ?? undefined}
                mapView={this.mapViewRef.current || undefined}
                jimuMapView={this.state.jimuMapView}
                onInitializeGraphicsLayer={this.initializeGraphicsLayerFromOutputDS}
                onClearGraphicsLayer={this.clearGraphicsLayerIfExists}
                onDestroyGraphicsLayer={this.clearGraphicsLayerRefs}
                activeTab={this.state.activeTab}
                onTabChange={this.handleTabChange}
                eventManager={this.eventManager}
                isPanelVisible={this.state.isPanelVisible}
              />
          </TaskListPopperWrapper>
        </QueryWidgetContext.Provider>
      )
    }

    if (config.arrangeType === QueryArrangeType.Inline && !controllerWidgetId) {
      return (
        <QueryWidgetContext.Provider value={`${layoutId}:${layoutItemId}`}>
          <TaskListInline
            widgetId={id}
            widgetLabel={label}
            wrap={config.arrangeWrap}
            queryItems={config.queryItems}
            minSize={config.sizeMap?.arrangementIconPopper?.minSize}
            defaultSize={config.sizeMap?.arrangementIconPopper?.defaultSize}
            initialQueryValue={this.state.initialQueryValue}
            onHashParameterUsed={this.handleHashParameterUsed}
          />
        </QueryWidgetContext.Provider>
      )
    }

    return (
      <Paper ref={this.widgetRef} variant='flat' className='jimu-widget runtime-query' data-widgetid={id} css={css`
        display: flex;
        flex-direction: column;
        height: 100%;
      `}>
        {/* Hidden JimuMapViewComponent to get map view for graphics layer */}
        {/* Uses explicit map widget ID from config (widget-level binding) */}
        {config.highlightMapWidgetId && (
          <JimuMapViewComponent
            useMapWidgetId={config.highlightMapWidgetId}
            onActiveViewChange={this.handleJimuMapViewChanged}
          />
        )}
        {widgetConfigManager.getShowHeader(id) && (
          <div className="widget-header" css={css`
            padding: 6px 16px;
            border-bottom: 1px solid var(--sys-color-divider-secondary);
            background-color: var(--sys-color-surface);
          `}>
            <h3 className="widget-title" css={css`
              margin: 0;
              font-size: 1rem;
              font-weight: 600;
              color: var(--sys-color-text-primary);
            `}>
              {label || widgetLabel}
            </h3>
          </div>
        )}
        <div css={css`
          flex: 1;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        `}>
          <div css={css`
            flex: 1;
            overflow: auto;
          `}>
            <QueryWidgetContext.Provider value={`${layoutId}:${layoutItemId}`}>
              <QueryTaskList 
                widgetId={id} 
                queryItems={config.queryItems} 
                initialQueryValue={this.state.initialQueryValue} 
                shouldUseInitialQueryValueForSelection={this.state.shouldUseInitialQueryValueForSelection}
                onHashParameterUsed={this.handleHashParameterUsed}
                resultsMode={this.state.resultsMode}
                onResultsModeChange={this.handleResultsModeChange}
                accumulatedRecords={this.state.accumulatedRecords}
                resultsExtent={this.state.resultsExtent}
                onAccumulatedRecordsChange={this.handleAccumulatedRecordsChange}
                graphicsLayer={this.graphicsLayerManager.getResultsLayer() ?? undefined}
                mapView={this.mapViewRef.current || undefined}
                onInitializeGraphicsLayer={this.initializeGraphicsLayerFromOutputDS}
                onClearGraphicsLayer={this.clearGraphicsLayerIfExists}
                onDestroyGraphicsLayer={this.clearGraphicsLayerRefs}
                activeTab={this.state.activeTab}
                onTabChange={this.handleTabChange}
                eventManager={this.eventManager}
                isPanelVisible={this.state.isPanelVisible}
                jimuMapView={this.state.jimuMapView}
              />
            </QueryWidgetContext.Provider>
          </div>
          {/* Stationary footer */}
          <div css={css`
            padding: 4px 12px;
            border-top: 1px solid var(--sys-color-divider-secondary);
            background-color: var(--sys-color-surface-paper);
            flex-shrink: 0;
            text-align: center;
          `}>
            <span css={css`
              font-size: 0.75rem;
              color: var(--sys-color-text-tertiary);
              font-weight: 400;
              letter-spacing: 0.025em;
              display: inline-flex;
              align-items: center;
              gap: 4px;
            `}>
              {/* Code/Open Source Symbol */}
              <svg 
                width="14" 
                height="14" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2"
                css={css`
                  flex-shrink: 0;
                  opacity: 0.6;
                `}
              >
                <polyline points="16 18 22 12 16 6"/>
                <polyline points="8 6 2 12 8 18"/>
              </svg>
              QuerySimple by MapSimple
              <span css={css`
                margin-left: 6px;
                opacity: 0.5;
                font-size: 0.7rem;
              `}>
                v{WIDGET_VERSION}
              </span>
            </span>
          </div>
        </div>
      </Paper>
    )
  }
}

