import React from 'react'
import { type FeatureDataRecord } from 'jimu-core'
import { SelectionType } from '../../config'
import { createQuerySimpleDebugLogger } from 'widgets/shared-code/mapsimple-common'
import { graphicsStateManager } from '../graphics-state-manager'
import type GraphicsLayer from '@arcgis/core/layers/GraphicsLayer'
import type MapView from '@arcgis/core/views/MapView'
import type SceneView from '@arcgis/core/views/SceneView'
import type Layer from '@arcgis/core/layers/Layer'
// r028.094: Path 3 GroupLayer ID for the panel-reopen restoration optimization
// (see addSelectionToMap below). Pre-Phase-1 the optimization hardcoded Path 2's
// `querysimple-results-*` prefix; post-Phase-1 it must use Path 3's `querysimple-fl-*`.
import { getGroupLayerId as getPath3GroupLayerId } from '../result-feature-layer-factory'

const debugLogger = createQuerySimpleDebugLogger()

/**
 * Interface for widget state that relates to selection and restoration.
 * r022.2: lastSelection removed - accumulatedRecords is universal source of truth
 *
 * r027.079: All fields marked optional. The widget's State (in widget.tsx)
 * declares these fields with `?:` (all optional), and the stateGetter
 * returns the full widget State, so structural assignability requires
 * matching optionality. The manager's runtime code already handles
 * `undefined` for each (e.g., guards on hasSelection, defaults on
 * selectionRecordCount).
 */
export interface SelectionRestorationState {
  hasSelection?: boolean
  selectionRecordCount?: number
  resultsMode?: SelectionType
  // r027.072: Type was Array<{configId, record}> (a stale wrapper shape), but
  // every other place in the codebase uses FeatureDataRecord[] directly, and
  // the consumer code at line 322/326 calls record.getId()/getDataSource()
  // straight on the entries — confirming the runtime shape is bare records.
  accumulatedRecords?: FeatureDataRecord[]
  isPanelVisible?: boolean
}

/**
 * Interface for callbacks to update widget state.
 */
export interface SelectionRestorationCallbacks {
  onStateUpdate: (newState: Partial<SelectionRestorationState>) => void
}

/**
 * Dependencies needed for panel restoration methods.
 * These are typically passed at runtime when calling addSelectionToMap/clearSelectionFromMap.
 *
 * r027.079: Widened to match what widget.tsx actually passes:
 *   - mapViewRef can hold MapView OR SceneView (3D mode).
 *   - graphicsLayerManager param is typed loosely (it's a class instance);
 *     only clearGraphics is exercised here, and we keep the structural
 *     surface narrow to that one method.
 */
export interface RestorationDependencies {
  graphicsLayerRef: { current: GraphicsLayer | null }
  mapViewRef: { current: MapView | SceneView | null }
  graphicsLayerManager: {
    clearGraphics: (widgetId: string, config: any) => void
  }
  config: Record<string, any>
}

/**
 * Manager class for handling selection state tracking and restoration logic.
 * 
 * This class centralizes the logic for:
 * - Section 3.1: Selection State Tracking (handleSelectionChange)
 * - Section 3.2: Panel Open/Close Restoration (addSelectionToMap, clearSelectionFromMap)
 * - Section 3.3: Map Identify Restoration (handleRestoreOnIdentifyClose)
 * 
 * Part of Chunk 3: Selection & Restoration extraction.
 * 
 * Note: This is a utility class (not a hook) to work with class components.
 */
export class SelectionRestorationManager {
  private widgetId: string = ''
  private stateGetter: () => SelectionRestorationState
  private callbacks: SelectionRestorationCallbacks

  constructor(
    stateGetter: () => SelectionRestorationState,
    callbacks: SelectionRestorationCallbacks
  ) {
    this.stateGetter = stateGetter
    this.callbacks = callbacks
  }

  /**
   * Sets the widget ID. Should be called once in componentDidMount.
   * @param widgetId - The widget ID
   */
  setWidgetId(widgetId: string): void {
    this.widgetId = widgetId
  }

  // ============================================================================
  // Section 3.1: Selection State Tracking
  // ============================================================================

  /**
   * Handles selection change events from queries.
   * 
   * This method:
   * 1. Ignores events not for this widget
   * 2. Ignores empty selections when panel is closed (to prevent state wipe)
   * 3. Calculates selection count (uses accumulated records in Add/Remove modes)
   * 4. Updates widget state: hasSelection, selectionRecordCount
   * 5. Resets mode to NewSelection if selection is cleared in Remove mode
   * 
   * r022.2: lastSelection removed from state updates
   * 
   * @param event - The selection change event
   */
  handleSelectionChange(event: Event): void {
    const customEvent = event as CustomEvent<{
      widgetId: string
      recordIds: string[]
      dataSourceId?: string
      outputDsId?: string
      queryItemConfigId?: string
      accumulatedRecordsCount?: number
    }>

    // Get current state
    const state = this.stateGetter()

    // ========================================================================
    // 1. Only track if this is for our widget
    // ========================================================================
    if (customEvent.detail.widgetId !== this.widgetId) {
      return
    }

    // ========================================================================
    // 2. Ignore empty selections when panel is closed
    // ========================================================================
    const hasSelection = customEvent.detail.recordIds && customEvent.detail.recordIds.length > 0

    if (!state.isPanelVisible && !hasSelection) {
      debugLogger.log('RESTORE', {
        event: 'handleSelectionChange-ignoring-empty-selection-while-panel-closed',
        widgetId: this.widgetId,
        timestamp: Date.now()
      })
      return
    }

    // ========================================================================
    // 3. Calculate selection count
    // ========================================================================
    const isAccumulationMode = state.resultsMode === SelectionType.AddToSelection ||
                               state.resultsMode === SelectionType.RemoveFromSelection
    const stateAccumulatedCount = state.accumulatedRecords?.length ?? 0
    const eventAccumulatedCount = customEvent.detail.accumulatedRecordsCount ?? 0
    // r022.43: FIX - Use stateAccumulatedCount (widget source of truth) not eventAccumulatedCount (stale hashEntry)
    // When switching layers in Add mode, HelperSimple hashEntry is stale (old layer count), but state is correct
    const selectionCount = isAccumulationMode && stateAccumulatedCount > 0
      ? stateAccumulatedCount
      : (hasSelection ? customEvent.detail.recordIds.length : 0)

    // ========================================================================
    // 4. Determine if mode should reset
    // ========================================================================
    // If selection is cleared in Remove mode, reset to NewSelection
    const shouldResetMode = !hasSelection && 
                            selectionCount === 0 && 
                            state.resultsMode === SelectionType.RemoveFromSelection

    // ========================================================================
    // 5. Build new state
    // ========================================================================
    // r022.2: lastSelection removed - accumulatedRecords is universal source of truth
    const newState: Partial<SelectionRestorationState> = {
      hasSelection: selectionCount > 0,
      selectionRecordCount: selectionCount
    }

    // Reset mode if needed
    if (shouldResetMode) {
      newState.resultsMode = SelectionType.NewSelection
      newState.accumulatedRecords = [] // Also clear accumulated records
    }

    // ========================================================================
    // 6. Log decision logic
    // ========================================================================
    debugLogger.log('RESTORE', {
      event: 'handleSelectionChange-updating-state',
      widgetId: this.widgetId,
      resultsMode: state.resultsMode,
      isAccumulationMode,
      eventRecordIdsCount: customEvent.detail.recordIds.length,
      hasSelectionFromEvent: hasSelection,
      eventAccumulatedCount,
      stateAccumulatedCount,
      calculatedSelectionCount: selectionCount,
      'will-set-hasSelection': selectionCount > 0,
      'will-reset-mode': shouldResetMode,
      decisionLogic: {
        isAccumulationMode,
        'stateAccumulatedCount > 0': stateAccumulatedCount > 0,
        'use-state-accumulated-count': isAccumulationMode && stateAccumulatedCount > 0,
        'should-reset-mode': shouldResetMode,
        note: 'r022.43: Using stateAccumulatedCount (widget state) not eventAccumulatedCount (stale hashEntry)'
      }
    })

    // ========================================================================
    // 7. Update state via callback
    // ========================================================================
    this.callbacks.onStateUpdate(newState)

    // ========================================================================
    // 8. Log state AFTER update
    // ========================================================================
    debugLogger.log('RESTORE', {
      event: 'handleSelectionChange-state-updated',
      widgetId: this.widgetId,
      'new-hasSelection': selectionCount > 0,
      'new-selectionRecordCount': selectionCount,
      'mode-reset': shouldResetMode,
      'new-mode': shouldResetMode ? SelectionType.NewSelection : state.resultsMode,
      note: shouldResetMode 
        ? 'Mode reset to NewSelection because selection was cleared in Remove mode'
        : 'r022.2: lastSelection removed - accumulatedRecords is universal source'
    })
  }

  // ============================================================================
  // Section 3.2: Panel Open/Close Restoration
  // ============================================================================

  /**
   * Restores selection to the map when the widget panel opens.
   * 
   * This method:
   * 1. Checks if accumulated records exist (ALL modes)
   * 2. Groups accumulated records by origin data source
   * 3. r023.10: Origin DS selection removed (was causing blue outlines)
   * 
   * r022.2: lastSelection fallback removed - accumulatedRecords is universal source
   * r022.41: Added manageGraphicsLayer parameter for shared restoration path
   * r024.3: When LayerList mode enabled and GroupLayer exists, skip restoration
   * 
   * @param deps - Runtime dependencies (graphics layer, map view, config)
   * @param manageGraphicsLayer - If true (default), clears and re-adds graphics layer.
   *                              If false, skips graphics operations (e.g., for Identify popup restore)
   */
  async addSelectionToMap(deps: RestorationDependencies, manageGraphicsLayer: boolean = true): Promise<void> {
    const state = this.stateGetter()
    const { accumulatedRecords, resultsMode } = state

    // r024.3: Check if LayerList mode is enabled
    const addResultsAsMapLayer = (deps.config as any)?.addResultsAsMapLayer === true
    const mapView = deps.mapViewRef.current

    debugLogger.log('RESTORE', {
      event: 'addSelectionToMap-called',
      widgetId: this.widgetId,
      resultsMode,
      hasAccumulatedRecords: !!(accumulatedRecords && accumulatedRecords.length > 0),
      accumulatedRecordsCount: accumulatedRecords?.length || 0,
      addResultsAsMapLayer,
      note: 'r022.2: lastSelection removed - accumulatedRecords is universal source of truth'
    })

    // r024.3 (original): When LayerList mode is enabled and the persistent results
    // GroupLayer is still on the map, skip restoration — the results survived the
    // panel close and don't need to be re-drawn.
    //
    // r028.094: Repointed at Path 3's GroupLayer ID. The optimization's intent
    // applies equally to Path 3 (results in FeatureLayers inside `querysimple-fl-*`
    // GroupLayer) as it did to Path 2 (`querysimple-results-*`). The hardcoded
    // prefix was a pre-Phase-1 holdover that silently stopped firing once Phase 1
    // flipped `addResultsAsMapLayer` semantics from "use Path 2" to "use Path 3",
    // causing redundant restoration work on every Path-3 panel reopen.
    if (addResultsAsMapLayer && mapView) {
      const groupLayerId = getPath3GroupLayerId(this.widgetId)
      const existingGroupLayer = mapView.map.layers.find((layer: Layer) => layer.id === groupLayerId)
      if (existingGroupLayer) {
        debugLogger.log('RESTORE', {
          event: 'addSelectionToMap-skipped-layerlist-mode',
          widgetId: this.widgetId,
          groupLayerId,
          note: 'r028.094: Path 3 GroupLayer present — results persist across panel close, skipping restoration'
        })
        return
      }
    }

    // r022.1/r022.2: Use accumulatedRecords for ALL modes (reflects removals)
    // accumulatedRecords is universal source of truth across New/Add/Remove modes
    if (accumulatedRecords && accumulatedRecords.length > 0) {
      debugLogger.log('RESTORE', {
        event: 'addSelectionToMap-found-accumulated-records',
        widgetId: this.widgetId,
        resultsMode,
        accumulatedRecordsCount: accumulatedRecords.length,
        manageGraphicsLayer
      })
      
      await this.restoreAccumulatedRecords(accumulatedRecords, deps, manageGraphicsLayer)
    } else {
      debugLogger.log('RESTORE', {
        event: 'addSelectionToMap-no-selection-to-restore',
        widgetId: this.widgetId,
        resultsMode,
        note: 'r022.2: No accumulated records - nothing to restore'
      })
    }

    // r025.020: Restore buffer graphic on panel reopen (non-LayerList mode).
    // Symmetric with clearSelectionFromMap which clears the buffer (r025.017).
    if (!addResultsAsMapLayer && mapView) {
      const bufferLayerId = `querysimple-buffer-${this.widgetId}`
      const bufferLayer = mapView.map.findLayerById(bufferLayerId) as GraphicsLayer
      const lastGraphic = graphicsStateManager.getLastBufferGraphic(this.widgetId)

      if (bufferLayer && lastGraphic && bufferLayer.graphics?.length === 0) {
        bufferLayer.add(lastGraphic)
        debugLogger.log('RESTORE', {
          event: 'buffer-preview-restored-on-panel-open',
          widgetId: this.widgetId,
          bufferLayerId,
          timestamp: Date.now()
        })
      }
    }
  }

  /**
   * Helper: Restore accumulated records (grouped by origin DS)
   * r022.41: Added manageGraphicsLayer parameter
   */
  private async restoreAccumulatedRecords(
    // r027.072: Param type was the same stale wrapper shape as the state field;
    // narrowed to FeatureDataRecord[] to match the runtime value passed at
    // line 276 and the rest of the codebase.
    accumulatedRecords: FeatureDataRecord[],
    deps: RestorationDependencies,
    manageGraphicsLayer: boolean
  ): Promise<void> {
    // Lazy-load dependencies
    const { DataSourceManager } = await import('jimu-core')
    const recordsByOriginDS = new Map<any, any[]>() // Map<FeatureLayerDataSource, FeatureDataRecord[]>
    const dsManager = DataSourceManager.getInstance()

    // Group records by origin DS
    accumulatedRecords.forEach((record, index) => {
      // r027.000: ExB 1.20 — coerce getId() to string (now returns string | number)
      const recordId = String(record.getId())
      let originDS: any | null = null

      // Method 1: Try to get from record.dataSource
      // r027.072: ExB 1.20 — DataRecord exposes .dataSource as a property
      // (line 372 of common-data-source-interface.d.ts). Old getDataSource()
      // method does not exist in 1.20.
      const recordDS = record.dataSource
      if (recordDS) {
        originDS = recordDS.getOriginDataSources?.()?.[0] || recordDS

        debugLogger.log('RESTORE', {
          event: 'found-origin-ds-from-record-ds',
          widgetId: this.widgetId,
          recordIndex: index,
          recordId,
          originDSId: originDS?.id || 'null',
          method: 'record.getDataSource()'
        })
      }

      // Method 2: If that failed, search all data sources for a record with matching ID
      if (!originDS) {
        const dsMap = dsManager.getDataSources()
        const allDataSources = Object.values(dsMap)

        for (const ds of allDataSources) {
          // Check if this is a FeatureLayerDataSource
          if (ds && typeof (ds as any).getAllLoadedRecords === 'function') {
            try {
              const allRecords = (ds as any).getAllLoadedRecords() || []
              // r027.000: ExB 1.20 — coerce getId() to string (now returns string | number)
              const matchingRecord = allRecords.find((r: any) => String(r.getId()) === recordId)

              if (matchingRecord) {
                originDS = (ds as any).getOriginDataSources?.()?.[0] || ds

                debugLogger.log('RESTORE', {
                  event: 'found-origin-ds-via-search',
                  widgetId: this.widgetId,
                  recordIndex: index,
                  recordId,
                  originDSId: originDS.id,
                  method: 'searched-all-data-sources',
                  searchedDSId: ds.id
                })
                break
              }
            } catch (error) {
              // Continue searching
            }
          }
        }
      }

      if (originDS) {
        if (!recordsByOriginDS.has(originDS)) {
          recordsByOriginDS.set(originDS, [])
        }
        recordsByOriginDS.get(originDS)!.push(record)
      } else {
        debugLogger.log('RESTORE', {
          event: 'could-not-find-origin-ds-for-record',
          widgetId: this.widgetId,
          recordIndex: index,
          recordId,
          warning: 'record-will-be-skipped'
        })
      }
    })

    debugLogger.log('RESTORE', {
      event: 'panel-opened-restoring-accumulated-records',
      widgetId: this.widgetId,
      resultsMode: this.stateGetter().resultsMode,
      accumulatedRecordsCount: accumulatedRecords.length,
      originDSCount: recordsByOriginDS.size
    })

    // Restore selection for each origin data source
    const graphicsLayer = deps.graphicsLayerRef.current || undefined
    const mapView = deps.mapViewRef.current || undefined

    // r022.41: Conditionally manage graphics layer based on caller context
    // Widget close/open: manageGraphicsLayer=true (clears and re-adds graphics)
    // Identify popup restore: manageGraphicsLayer=false (graphics already visible, just restore DS selection)
    if (manageGraphicsLayer && graphicsLayer && mapView) {
      const { clearGraphicsLayer: clearGL, addHighlightGraphics } = await import('../graphics-layer-utils')
      
      // r027.072: Removed legacy debug-log probe of {configId, record} wrapper
      // shape. The comment one block down (and the rest of the codebase)
      // confirms accumulatedRecords are bare FeatureDataRecord objects, so
      // probing for the old wrapper fields was diagnostic noise from the
      // wrapper -> bare-record transition that's already complete.
      debugLogger.log('RESTORE', {
        event: 'clearing-graphics-before-restore',
        widgetId: this.widgetId,
        graphicsLayerId: graphicsLayer.id,
        graphicsCountBefore: graphicsLayer.graphics.length,
        manageGraphicsLayer,
        accumulatedRecordsCount: accumulatedRecords.length,
        sampleRecordIds: accumulatedRecords.slice(0, 5).map(r => String(r.getId())),
        timestamp: Date.now()
      })
      
      clearGL(graphicsLayer)
      
      // r021.93: accumulatedRecords are the raw FeatureDataRecord objects, not wrapped
      // Filter out any null/undefined entries
      const validRecords = accumulatedRecords.filter(record => record != null)
      
      await addHighlightGraphics(graphicsLayer, validRecords, mapView)
      
      debugLogger.log('RESTORE', {
        event: 'graphics-restored-in-batch',
        widgetId: this.widgetId,
        graphicsLayerId: graphicsLayer.id,
        accumulatedRecordsCount: accumulatedRecords.length,
        validRecordsCount: validRecords.length,
        finalGraphicsCount: graphicsLayer.graphics.length,
        manageGraphicsLayer,
        timestamp: Date.now()
      })
    } else if (!manageGraphicsLayer) {
      debugLogger.log('RESTORE', {
        event: 'graphics-management-skipped',
        widgetId: this.widgetId,
        manageGraphicsLayer,
        reason: 'caller-requested-skip-graphics-layer',
        note: 'r022.41: Used for Identify popup restore where graphics already visible',
        timestamp: Date.now()
      })
    }

    // r023.10: Origin DS loop REMOVED. Previously iterated over origin DSes and called
    // selectRecordsAndPublish per DS, which passed originDS as outputDS parameter.
    // This caused blue outlines via:
    //   1. outputDS.selectRecordsByIds() (line 210 in selectRecordsInDataSources) was actually
    //      calling originDS.selectRecordsByIds() since originDS was passed as outputDS
    //   2. publishSelectionMessage() published DataRecordsSelectionChangeMessage for origin DS
    //
    // Graphics are already restored above (lines 362-409).
    // Output DS selection (Results tab borders) is handled by handleOutputDataSourceCreated
    // in query-task.tsx when the widget re-renders after panel reopen.
    debugLogger.log('RESTORE', {
      event: 'panel-opened-graphics-restored-skipping-origin-ds',
      widgetId: this.widgetId,
      accumulatedRecordsCount: accumulatedRecords.length,
      originDSCount: recordsByOriginDS.size,
      note: 'r023.10: Origin DS selection removed to prevent blue outlines'
    })
  }

  // r022.2: restoreLastSelection() method removed - dead code after r022.1 fix
  // r022.1 made accumulatedRecords the universal restoration source for ALL modes

  /**
   * Clears widget graphics from the map when the widget panel closes.
   * 
   * This method:
   * 1. Clears graphics layer (purple highlights) - UNLESS LayerList mode enabled
   * 2. Does NOT clear origin DS selection (blue outlines from "Select on Map")
   * 
   * r022.2: lastSelection fallback removed - accumulatedRecords is universal source
   * r023.10: Origin DS clearing removed. Explicit "Select on Map" blue outlines
   * persist through panel close/reopen. Only (X) and Clear All remove them.
   * r024.3: When LayerList mode enabled, skip graphics clear (GroupLayer persists)
   * 
   * @param deps - Runtime dependencies (graphics layer, map view, config)
   */
  async clearSelectionFromMap(deps: RestorationDependencies): Promise<void> {
    const state = this.stateGetter()
    const { accumulatedRecords, resultsMode } = state

    // r024.3: Check if LayerList mode is enabled - if so, skip clearing graphics
    const addResultsAsMapLayer = (deps.config as any)?.addResultsAsMapLayer === true

    debugLogger.log('RESTORE', {
      event: 'clearSelectionFromMap-called',
      widgetId: this.widgetId,
      resultsMode,
      hasAccumulatedRecords: !!(accumulatedRecords && accumulatedRecords.length > 0),
      accumulatedRecordsCount: accumulatedRecords?.length || 0,
      addResultsAsMapLayer,
      note: addResultsAsMapLayer 
        ? 'r024.3: LayerList mode - graphics will persist' 
        : 'r022.2: lastSelection removed - using accumulatedRecords only'
    })

    // r024.3: Skip graphics clear when LayerList mode is enabled (GroupLayer persists)
    if (addResultsAsMapLayer) {
      debugLogger.log('RESTORE', {
        event: 'panel-closed-graphics-persist-layerlist-mode',
        widgetId: this.widgetId,
        note: 'r024.3: GroupLayer persists when widget closes - skipping graphics clear'
      })
    } else if (deps.graphicsLayerRef.current) {
      // Original behavior: clear graphics when panel closes
      deps.graphicsLayerManager.clearGraphics(this.widgetId, deps.config)
      debugLogger.log('RESTORE', {
        event: 'panel-closed-graphics-layer-cleared',
        widgetId: this.widgetId,
        graphicsLayerId: deps.graphicsLayerRef.current.id
      })

      // r025.017: Also clear buffer preview graphics on panel close.
      // In non-LayerList mode the buffer layer is standalone on the map
      // (not inside a GroupLayer), so clearGraphicsLayerOrGroupLayer()
      // only clears highlight graphics — it doesn't touch the buffer.
      const mapView = deps.mapViewRef?.current
      if (mapView) {
        const bufferLayerId = `querysimple-buffer-${this.widgetId}`
        const bufferLayer = mapView.map.findLayerById(bufferLayerId) as GraphicsLayer
        if (bufferLayer && bufferLayer.graphics?.length > 0) {
          const bufferCount = bufferLayer.graphics.length
          bufferLayer.removeAll()
          debugLogger.log('RESTORE', {
            event: 'buffer-preview-cleared-on-panel-close',
            widgetId: this.widgetId,
            bufferLayerId,
            graphicsCleared: bufferCount,
            timestamp: Date.now()
          })
        }
      }
    }

    // r023.10: Origin DS clearing REMOVED from panel close.
    // Previously called clearAccumulatedRecords() which cleared origin DS selection per DS.
    // This destroyed explicit "Select on Map" blue outlines when closing the panel,
    // and since r023.10 removed origin DS restoration on reopen, they'd never come back.
    // Now only (X) remove and Clear All clear origin DS selection (explicit user actions).
    // Graphics layer is already cleared above (lines 457-464) and restored on reopen.
    // r023.12: Still clean the data_s hash parameter on panel close.
    // ExB adds data_s when selections are made but doesn't remove it when the widget closes.
    // This prevents "dirty hash" issues without clearing the actual origin DS selection.
    const { clearDataSParameterFromHash } = await import('../selection-utils')
    clearDataSParameterFromHash()

    debugLogger.log('RESTORE', {
      event: 'panel-closed-hash-cleaned-origin-ds-preserved',
      widgetId: this.widgetId,
      accumulatedRecordsCount: accumulatedRecords?.length || 0,
      note: 'r023.12: data_s hash cleared, origin DS selection preserved'
    })
  }

  // r024.112: clearAccumulatedRecords() removed — never called (dead since r023.10).
  // r022.2: clearLastSelection() removed — dead code after r022.1 fix.

  // ============================================================================
  // Section 3.3: Map Identify Restoration
  // ============================================================================
  // TODO: Implement handleRestoreOnIdentifyClose()
}
